-- ============================================
-- Ethiopian Restaurant Management System Database
-- T-Launge Restaurant - Complete Setup
-- ============================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS restaurant_database;
USE restaurant_database;

-- ============================================
-- 1. ADMINS TABLE
-- ============================================
CREATE TABLE admins (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 2. CUSTOMERS TABLE
-- ============================================
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    phone_number VARCHAR(15) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    address TEXT,
    customer_type ENUM('REGISTERED', 'GUEST') DEFAULT 'REGISTERED',
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_orders INT DEFAULT 0,
    total_spent DECIMAL(10,2) DEFAULT 0.00,
    INDEX idx_phone (phone_number)
);

-- ============================================
-- 3. CATEGORIES TABLE (Ethiopian Food Categories)
-- ============================================
CREATE TABLE categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 4. MENU_ITEMS TABLE (Ethiopian Food Items)
-- ============================================
CREATE TABLE menu_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE
);

-- ============================================
-- 5. ORDERS TABLE
-- ============================================
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    customer_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    delivery_address TEXT,
    special_instructions TEXT,
    receipt_photo LONGBLOB,
    receipt_filename VARCHAR(255),
    receipt_file_hash VARCHAR(255),
    receipt_amount DECIMAL(10,2),
    total_amount DECIMAL(10,2) NOT NULL,
    delivery_required BOOLEAN DEFAULT FALSE,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    receipt_status ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
    rejection_reason TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

-- ============================================
-- 6. ORDER_ITEMS TABLE
-- ============================================
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id) ON DELETE CASCADE
);

-- ============================================
-- 7. PAYMENTS TABLE (Optional)
-- ============================================
CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    customer_id INT,
    payment_method ENUM('TELE_BIRR', 'CBE_BIRR', 'CASH') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transaction_id VARCHAR(100),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('PENDING', 'COMPLETED', 'FAILED') DEFAULT 'PENDING',
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

-- ============================================
-- INSERT INITIAL DATA
-- ============================================

-- Insert default admin (password: admin123)
INSERT INTO admins (username, password, full_name, role) VALUES
('admin', 'admin123', 'System Administrator', 'Super Admin');

-- Insert Ethiopian Food Categories
INSERT INTO categories (category_name, description) VALUES
('Traditional Dishes', 'Authentic Ethiopian traditional dishes'),
('Meat Dishes', 'Ethiopian meat-based dishes'),
('Vegetarian Dishes', 'Vegetarian Ethiopian dishes'),
('Injera & Breads', 'Traditional Ethiopian injera and breads'),
('Breakfast', 'Ethiopian breakfast items'),
('Side Dishes', 'Side dishes and salads'),
('Beverages', 'Traditional Ethiopian beverages'),
('Desserts', 'Sweet treats and desserts');

-- Insert Ethiopian Food Items

-- Traditional Dishes (category_id = 1)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(1, 'Doro Wat', 'Spicy chicken stew with hard-boiled eggs', 250.00),
(1, 'Key Wat', 'Spicy beef stew', 230.00),
(1, 'Tibs', 'Sautéed meat with vegetables', 220.00),
(1, 'Kitfo', 'Minced raw beef seasoned with spices', 240.00),
(1, 'Shiro Wat', 'Spiced chickpea or bean stew', 150.00);

-- Meat Dishes (category_id = 2)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(2, 'Beyaynetu', 'Mixed vegetarian platter with meat', 280.00),
(2, 'Gomen Wat', 'Collard greens stew with meat', 200.00),
(2, 'Bozena Shiro', 'Shiro with meat', 210.00);

-- Vegetarian Dishes (category_id = 3)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(3, 'Misir Wat', 'Spicy red lentil stew', 120.00),
(3, 'Kik Alicha', 'Yellow split pea stew', 120.00),
(3, 'Atakilt Wat', 'Cabbage, potato, and carrot stew', 110.00),
(3, 'Fosolia', 'Green beans and carrots', 100.00);

-- Injera & Breads (category_id = 4)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(4, 'Injera', 'Traditional sourdough flatbread', 50.00),
(4, 'Dabo', 'Ethiopian bread', 40.00),
(4, 'Defo Dabo', 'Traditional Ethiopian holiday bread', 80.00);

-- Breakfast (category_id = 5)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(5, 'Ful', 'Fava bean stew', 90.00),
(5, 'Chechebsa', 'Shredded injera with spices and butter', 70.00),
(5, 'Genfo', 'Porridge made from barley flour', 60.00);

-- Side Dishes (category_id = 6)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(6, 'Ayib', 'Ethiopian cottage cheese', 40.00),
(6, 'Timatim', 'Tomato salad', 30.00),
(6, 'Gomen', 'Collard greens', 35.00);

-- Beverages (category_id = 7)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(7, 'Tej', 'Traditional Ethiopian honey wine', 120.00),
(7, 'Coffee', 'Traditional Ethiopian coffee ceremony', 80.00),
(7, 'Shai', 'Ethiopian tea', 30.00);

-- Desserts (category_id = 8)
INSERT INTO menu_items (category_id, item_name, description, price) VALUES
(8, 'Baklava', 'Sweet pastry with nuts and honey', 60.00),
(8, 'Dabo Kolo', 'Small pieces of roasted bread', 40.00),
(8, 'Yeshimbra Assa', 'Chickpea flour cookies', 50.00);

-- ============================================
-- CREATE INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_customers_phone ON customers(phone_number);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_menu_category ON menu_items(category_id);
CREATE INDEX idx_order_items_order ON order_items(order_id);

-- ============================================
-- CREATE STORED PROCEDURES
-- ============================================
DELIMITER //

-- Procedure to get daily sales report
CREATE PROCEDURE GetDailySales(IN report_date DATE)
BEGIN
    SELECT 
        DATE(o.order_date) as sale_date,
        COUNT(*) as total_orders,
        SUM(o.total_amount) as total_revenue,
        AVG(o.total_amount) as average_order_value
    FROM orders o
    WHERE DATE(o.order_date) = report_date
        AND o.receipt_status = 'APPROVED'
    GROUP BY DATE(o.order_date);
END //

-- Procedure to update customer statistics
CREATE PROCEDURE UpdateCustomerStats(IN cust_id INT)
BEGIN
    UPDATE customers c
    SET 
        c.total_orders = (SELECT COUNT(*) FROM orders WHERE customer_id = cust_id),
        c.total_spent = (SELECT COALESCE(SUM(total_amount), 0) FROM orders 
                        WHERE customer_id = cust_id AND receipt_status = 'APPROVED')
    WHERE c.customer_id = cust_id;
END //

-- Procedure to get popular menu items
CREATE PROCEDURE GetPopularItems(IN days_back INT)
BEGIN
    SELECT 
        mi.item_id,
        mi.item_name,
        c.category_name,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.quantity * oi.unit_price) as total_revenue
    FROM order_items oi
    JOIN menu_items mi ON oi.item_id = mi.item_id
    JOIN categories c ON mi.category_id = c.category_id
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.order_date >= DATE_SUB(NOW(), INTERVAL days_back DAY)
        AND o.receipt_status = 'APPROVED'
    GROUP BY mi.item_id, mi.item_name, c.category_name
    ORDER BY total_quantity DESC
    LIMIT 10;
END //

DELIMITER ;

-- ============================================
-- CREATE VIEWS
-- ============================================

-- View for active menu items
CREATE VIEW active_menu_items AS
SELECT 
    mi.item_id,
    mi.item_name,
    mi.description,
    mi.price,
    c.category_name,
    mi.available
FROM menu_items mi
JOIN categories c ON mi.category_id = c.category_id
WHERE mi.available = TRUE
ORDER BY c.category_name, mi.item_name;

-- View for order details with customer info
CREATE VIEW order_details AS
SELECT 
    o.order_id,
    o.customer_name,
    o.phone_number,
    o.total_amount,
    o.receipt_status,
    o.order_date,
    c.email,
    c.address
FROM orders o
LEFT JOIN customers c ON o.customer_id = c.customer_id
ORDER BY o.order_date DESC;

-- View for sales summary
CREATE VIEW sales_summary AS
SELECT 
    DATE(o.order_date) as sale_date,
    COUNT(*) as orders_count,
    SUM(o.total_amount) as daily_revenue,
    AVG(o.total_amount) as avg_order_value
FROM orders o
WHERE o.receipt_status = 'APPROVED'
GROUP BY DATE(o.order_date);

-- ============================================
-- INSERT TEST DATA
-- ============================================

-- Insert test customers
INSERT INTO customers (phone_number, password_hash, full_name, email, address) VALUES
('0912345678', SHA2('password123', 256), 'Test Customer 1', 'test1@email.com', 'Addis Ababa'),
('0923456789', SHA2('password123', 256), 'Test Customer 2', 'test2@email.com', 'Adama'),
('0934567890', SHA2('password123', 256), 'Test Customer 3', 'test3@email.com', 'Bahir Dar');

-- Insert test orders
INSERT INTO orders (customer_id, customer_name, phone_number, total_amount, receipt_status) VALUES
(1, 'Test Customer 1', '0912345678', 450.00, 'APPROVED'),
(2, 'Test Customer 2', '0923456789', 320.00, 'PENDING'),
(3, 'Test Customer 3', '0934567890', 560.00, 'APPROVED');

-- Insert test order items
INSERT INTO order_items (order_id, item_id, quantity, unit_price) VALUES
(1, 1, 1, 250.00),  -- Doro Wat
(1, 12, 2, 50.00),  -- Injera
(1, 7, 1, 120.00),  -- Misir Wat
(2, 2, 1, 230.00),  -- Key Wat
(2, 12, 2, 50.00),  -- Injera
(3, 1, 2, 250.00),  -- Doro Wat (2x)
(3, 3, 1, 220.00),  -- Tibs
(3, 12, 4, 50.00);  -- Injera (4x)

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Show table counts
SELECT 'Admins' as table_name, COUNT(*) as record_count FROM admins
UNION ALL
SELECT 'Categories', COUNT(*) FROM categories
UNION ALL
SELECT 'Menu Items', COUNT(*) FROM menu_items
UNION ALL
SELECT 'Customers', COUNT(*) FROM customers
UNION ALL
SELECT 'Orders', COUNT(*) FROM orders
UNION ALL
SELECT 'Order Items', COUNT(*) FROM order_items;

-- Show menu items by category
SELECT 
    c.category_name,
    mi.item_name,
    mi.price,
    CASE WHEN mi.available THEN 'Yes' ELSE 'No' END as available
FROM menu_items mi
JOIN categories c ON mi.category_id = c.category_id
ORDER BY c.category_name, mi.item_name;

-- ============================================
-- FINAL MESSAGE
-- ============================================
SELECT '✅ Database setup completed successfully!' as message;
SELECT CONCAT('📊 Total food items: ', COUNT(*)) as summary FROM menu_items;