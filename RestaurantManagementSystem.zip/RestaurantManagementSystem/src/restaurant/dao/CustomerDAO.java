package restaurant.dao;

import restaurant.models.Customer;
import restaurant.db.DatabaseConnection;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class CustomerDAO {
    
    public Customer loginCustomer(String phoneNumber, String password) {
        String query = "SELECT * FROM customers WHERE phone_number = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, phoneNumber);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // Get stored password hash
                    String storedPasswordHash = rs.getString("password_hash");
                    
                    // Hash the provided password
                    String providedPasswordHash = hashPassword(password);
                    
                    // Verify password
                    if (storedPasswordHash != null && storedPasswordHash.equals(providedPasswordHash)) {
                        Customer customer = new Customer();
                        customer.setCustomerId(rs.getInt("customer_id"));
                        customer.setPhoneNumber(rs.getString("phone_number"));
                        customer.setFullName(rs.getString("full_name"));
                        customer.setEmail(rs.getString("email"));
                        customer.setAddress(rs.getString("address"));
                        customer.setCustomerType(rs.getString("customer_type"));
                        customer.setTotalOrders(rs.getInt("total_orders"));
                        customer.setTotalSpent(rs.getDouble("total_spent"));
                        customer.setRegistrationDate(rs.getTimestamp("registration_date"));
                        
                        System.out.println("Customer login successful: " + customer.getFullName());
                        return customer;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error during customer login: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean registerCustomer(Customer customer) {
        // Check if customer already exists
        if (customerExists(customer.getPhoneNumber())) {
            System.err.println("Customer with phone " + customer.getPhoneNumber() + " already exists");
            return false;
        }
        
        String query = "INSERT INTO customers (phone_number, password_hash, full_name, email, address, customer_type) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, customer.getPhoneNumber());
            
            // Hash the password before storing
            String hashedPassword = hashPassword(customer.getPassword());
            pstmt.setString(2, hashedPassword);
            
            pstmt.setString(3, customer.getFullName());
            pstmt.setString(4, customer.getEmail());
            pstmt.setString(5, customer.getAddress());
            pstmt.setString(6, "REGISTERED");
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                // Retrieve the generated customer_id
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        customer.setCustomerId(generatedKeys.getInt(1));
                    }
                }
                System.out.println("Customer registration SUCCESS for: " + customer.getFullName());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error registering customer: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean customerExists(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return false;
        }
        
        String query = "SELECT COUNT(*) as count FROM customers WHERE phone_number = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, phoneNumber.trim());
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt("count");
                    return count > 0;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking if customer exists: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean customerEmailExists(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        
        String query = "SELECT COUNT(*) as count FROM customers WHERE email = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, email.trim());
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt("count");
                    return count > 0;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking if email exists: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean updateCustomerStats(int customerId, double totalAmount) {
        String query = "UPDATE customers SET total_orders = total_orders + 1, total_spent = total_spent + ? WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setDouble(1, totalAmount);
            pstmt.setInt(2, customerId);
            
            int result = pstmt.executeUpdate();
            System.out.println("Updated customer stats for ID " + customerId + 
                              ", amount: $" + totalAmount + ", success: " + (result > 0));
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating customer stats: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public Customer getCustomerById(int customerId) {
        String query = "SELECT * FROM customers WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, customerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Customer customer = new Customer();
                    customer.setCustomerId(rs.getInt("customer_id"));
                    customer.setPhoneNumber(rs.getString("phone_number"));
                    customer.setFullName(rs.getString("full_name"));
                    customer.setEmail(rs.getString("email"));
                    customer.setAddress(rs.getString("address"));
                    customer.setCustomerType(rs.getString("customer_type"));
                    customer.setTotalOrders(rs.getInt("total_orders"));
                    customer.setTotalSpent(rs.getDouble("total_spent"));
                    customer.setRegistrationDate(rs.getTimestamp("registration_date"));
                    return customer;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting customer by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public Customer getCustomerByPhone(String phoneNumber) {
        String query = "SELECT * FROM customers WHERE phone_number = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, phoneNumber);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Customer customer = new Customer();
                    customer.setCustomerId(rs.getInt("customer_id"));
                    customer.setPhoneNumber(rs.getString("phone_number"));
                    customer.setFullName(rs.getString("full_name"));
                    customer.setEmail(rs.getString("email"));
                    customer.setAddress(rs.getString("address"));
                    customer.setCustomerType(rs.getString("customer_type"));
                    customer.setTotalOrders(rs.getInt("total_orders"));
                    customer.setTotalSpent(rs.getDouble("total_spent"));
                    customer.setRegistrationDate(rs.getTimestamp("registration_date"));
                    return customer;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting customer by phone: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean updateCustomer(Customer customer) {
        // Check if email is being changed and if new email already exists
        Customer existingCustomer = getCustomerById(customer.getCustomerId());
        if (existingCustomer != null) {
            String oldEmail = existingCustomer.getEmail();
            String newEmail = customer.getEmail();
            
            if (!oldEmail.equals(newEmail) && customerEmailExists(newEmail)) {
                System.err.println("Email " + newEmail + " already exists for another customer");
                return false;
            }
        }
        
        String query = "UPDATE customers SET full_name = ?, email = ?, address = ? WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, customer.getFullName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getAddress());
            pstmt.setInt(4, customer.getCustomerId());
            
            int result = pstmt.executeUpdate();
            System.out.println("Customer update for ID " + customer.getCustomerId() + ": " + (result > 0 ? "SUCCESS" : "FAILED"));
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM customers ORDER BY full_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setPhoneNumber(rs.getString("phone_number"));
                customer.setFullName(rs.getString("full_name"));
                customer.setEmail(rs.getString("email"));
                customer.setAddress(rs.getString("address"));
                customer.setCustomerType(rs.getString("customer_type"));
                customer.setTotalOrders(rs.getInt("total_orders"));
                customer.setTotalSpent(rs.getDouble("total_spent"));
                customer.setRegistrationDate(rs.getTimestamp("registration_date"));
                customers.add(customer);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all customers: " + e.getMessage());
            e.printStackTrace();
        }
        return customers;
    }
    
    public boolean deleteCustomer(int customerId) {
        String query = "DELETE FROM customers WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, customerId);
            
            int result = pstmt.executeUpdate();
            System.out.println("Customer deletion for ID " + customerId + ": " + (result > 0 ? "SUCCESS" : "FAILED"));
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting customer: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Password hashing method
    private String hashPassword(String password) {
        if (password == null || password.isEmpty()) {
            return "";
        }
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (Exception e) {
            System.err.println("Error hashing password: " + e.getMessage());
            return password; // Fallback
        }
    }
    
    public boolean testConnection() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null && !conn.isClosed()) {
                System.out.println("Database connection test: SUCCESS");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Database connection test failed: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}