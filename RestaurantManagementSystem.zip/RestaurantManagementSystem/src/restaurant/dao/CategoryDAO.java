package restaurant.dao;

import restaurant.db.DatabaseConnection;
import restaurant.models.Category;
import restaurant.models.MenuItem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {
    
    // Get category ID by category name
    public int getCategoryIdByName(String categoryName) {
        String query = "SELECT category_id FROM categories WHERE category_name = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, categoryName);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("category_id");
            }
        } catch (SQLException e) {
            System.err.println("Error getting category ID by name: " + e.getMessage());
            e.printStackTrace();
        }
        return -1;
    }
    
    // Get category name by category ID
    public String getCategoryNameById(int categoryId) {
        String query = "SELECT category_name FROM categories WHERE category_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getString("category_name");
            }
        } catch (SQLException e) {
            System.err.println("Error getting category name by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return "Unknown";
    }
    
    // Get category by ID
    public Category getCategoryById(int categoryId) {
        String query = "SELECT * FROM categories WHERE category_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new Category(
                    rs.getInt("category_id"),
                    rs.getString("category_name"),
                    rs.getString("description")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error getting category by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Get all categories
    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();
        String query = "SELECT * FROM categories ORDER BY category_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Category category = new Category(
                    rs.getInt("category_id"),
                    rs.getString("category_name"),
                    rs.getString("description")
                );
                categories.add(category);
            }
        } catch (SQLException e) {
            System.err.println("Error getting all categories: " + e.getMessage());
            e.printStackTrace();
        }
        return categories;
    }
    
    // Get menu items by category ID
    public List<MenuItem> getMenuItemsByCategory(int categoryId) {
        List<MenuItem> menuItems = new ArrayList<>();
        String query = "SELECT * FROM menu_items WHERE category_id = ? AND available = TRUE ORDER BY item_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                MenuItem item = new MenuItem(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getBoolean("available")
                );
                menuItems.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error getting menu items by category: " + e.getMessage());
            e.printStackTrace();
        }
        return menuItems;
    }
    
    // Get all menu items (from all categories)
    public List<MenuItem> getAllMenuItems() {
        List<MenuItem> menuItems = new ArrayList<>();
        String query = "SELECT * FROM menu_items WHERE available = TRUE ORDER BY item_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                MenuItem item = new MenuItem(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getBoolean("available")
                );
                menuItems.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error getting all menu items: " + e.getMessage());
            e.printStackTrace();
        }
        return menuItems;
    }
    
    // Get menu item by ID
    public MenuItem getMenuItemById(int itemId) {
        String query = "SELECT * FROM menu_items WHERE item_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, itemId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new MenuItem(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getBoolean("available")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error getting menu item by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Add a new category
    public boolean addCategory(Category category) {
        String query = "INSERT INTO categories (category_name, description) VALUES (?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, category.getCategoryName());
            pstmt.setString(2, category.getDescription());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error adding category: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Update a category
    public boolean updateCategory(Category category) {
        String query = "UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, category.getCategoryName());
            pstmt.setString(2, category.getDescription());
            pstmt.setInt(3, category.getCategoryId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating category: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete a category (and all its menu items)
    public boolean deleteCategory(int categoryId) {
        String query = "DELETE FROM categories WHERE category_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting category: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Search menu items by name or description
    public List<MenuItem> searchMenuItems(String searchText) {
        List<MenuItem> menuItems = new ArrayList<>();
        String query = "SELECT * FROM menu_items WHERE (item_name LIKE ? OR description LIKE ?) AND available = TRUE";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            String searchPattern = "%" + searchText + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                MenuItem item = new MenuItem(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getBoolean("available")
                );
                menuItems.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error searching menu items: " + e.getMessage());
            e.printStackTrace();
        }
        return menuItems;
    }
    
    // Get category statistics (item count, etc.)
    public int getCategoryItemCount(int categoryId) {
        String query = "SELECT COUNT(*) as item_count FROM menu_items WHERE category_id = ? AND available = TRUE";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("item_count");
            }
        } catch (SQLException e) {
            System.err.println("Error getting category item count: " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }
    
    // Get all menu items with category name
    public List<Object[]> getAllMenuItemsWithCategory() {
        List<Object[]> items = new ArrayList<>();
        String query = "SELECT mi.*, c.category_name FROM menu_items mi " +
                      "JOIN categories c ON mi.category_id = c.category_id " +
                      "WHERE mi.available = TRUE " +
                      "ORDER BY c.category_name, mi.item_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category_name"),
                    rs.getBoolean("available")
                };
                items.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Error getting all menu items with category: " + e.getMessage());
            e.printStackTrace();
        }
        return items;
    }
    
    // Get all available categories with item count
    public List<Object[]> getAllCategoriesWithItemCount() {
        List<Object[]> categories = new ArrayList<>();
        String query = "SELECT c.*, COUNT(mi.item_id) as item_count " +
                      "FROM categories c " +
                      "LEFT JOIN menu_items mi ON c.category_id = mi.category_id AND mi.available = TRUE " +
                      "GROUP BY c.category_id, c.category_name, c.description " +
                      "ORDER BY c.category_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("category_id"),
                    rs.getString("category_name"),
                    rs.getString("description"),
                    rs.getInt("item_count")
                };
                categories.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Error getting categories with item count: " + e.getMessage());
            e.printStackTrace();
        }
        return categories;
    }
    
    // Add a new menu item
    public boolean addMenuItem(MenuItem item) {
        String query = "INSERT INTO menu_items (category_id, item_name, description, price, available) " +
                      "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, item.getCategoryId());
            pstmt.setString(2, item.getItemName());
            pstmt.setString(3, item.getDescription());
            pstmt.setDouble(4, item.getPrice());
            pstmt.setBoolean(5, item.isAvailable());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error adding menu item: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Update a menu item
    public boolean updateMenuItem(MenuItem item) {
        String query = "UPDATE menu_items SET category_id = ?, item_name = ?, description = ?, " +
                      "price = ?, available = ? WHERE item_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, item.getCategoryId());
            pstmt.setString(2, item.getItemName());
            pstmt.setString(3, item.getDescription());
            pstmt.setDouble(4, item.getPrice());
            pstmt.setBoolean(5, item.isAvailable());
            pstmt.setInt(6, item.getItemId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating menu item: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete a menu item
    public boolean deleteMenuItem(int itemId) {
        String query = "DELETE FROM menu_items WHERE item_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, itemId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting menu item: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Search categories by name
    public List<Category> searchCategories(String searchText) {
        List<Category> categories = new ArrayList<>();
        String query = "SELECT * FROM categories WHERE category_name LIKE ? OR description LIKE ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            String searchPattern = "%" + searchText + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Category category = new Category(
                    rs.getInt("category_id"),
                    rs.getString("category_name"),
                    rs.getString("description")
                );
                categories.add(category);
            }
        } catch (SQLException e) {
            System.err.println("Error searching categories: " + e.getMessage());
            e.printStackTrace();
        }
        return categories;
    }
    
    // Get menu items by category and search
    public List<MenuItem> getMenuItemsByCategoryAndSearch(int categoryId, String searchText) {
        List<MenuItem> menuItems = new ArrayList<>();
        String query = "SELECT * FROM menu_items WHERE category_id = ? AND " +
                      "(item_name LIKE ? OR description LIKE ?) AND available = TRUE";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, categoryId);
            String searchPattern = "%" + searchText + "%";
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                MenuItem item = new MenuItem(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getBoolean("available")
                );
                menuItems.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error getting menu items by category and search: " + e.getMessage());
            e.printStackTrace();
        }
        return menuItems;
    }
    
    // Test database connection
    public boolean testConnection() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("Database connection test failed: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}