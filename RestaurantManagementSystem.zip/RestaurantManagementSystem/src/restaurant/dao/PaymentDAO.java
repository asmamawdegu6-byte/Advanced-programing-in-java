package restaurant.dao;

import restaurant.db.DatabaseConnection;
import restaurant.models.Payment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    
    // Create payments table if not exists
    public void createPaymentsTable() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS payments (" +
                "payment_id INT AUTO_INCREMENT PRIMARY KEY," +
                "order_id INT," +
                "payment_method VARCHAR(50) NOT NULL," +
                "amount DECIMAL(10,2) NOT NULL," +
                "phone_number VARCHAR(20)," +
                "sender_name VARCHAR(100)," +
                "account_number VARCHAR(50)," +
                "transaction_id VARCHAR(50) UNIQUE NOT NULL," +
                "status VARCHAR(20) DEFAULT 'Pending'," +
                "payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE SET NULL" +
                ")";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(createTableSQL);
            System.out.println("Payments table created/verified successfully.");
        } catch (SQLException e) {
            System.err.println("Error creating payments table: " + e.getMessage());
        }
    }
    
    // Save payment to database - returns boolean for success
    
    
        public boolean savePayment(Payment payment) {
    // VALIDATION: Check required fields
    if (payment == null) {
        System.err.println("Error: Payment is null!");
        return false;
    }
    
    if (payment.getPaymentMethod() == null || payment.getPaymentMethod().trim().isEmpty()) {
        System.err.println("Error: Payment method is null or empty!");
        return false;
    }
    
    if (payment.getTransactionId() == null || payment.getTransactionId().trim().isEmpty()) {
        System.err.println("Error: Transaction ID is null or empty!");
        return false;
    }
    
    System.out.println("Saving payment to database:");
    System.out.println("  Method: " + payment.getPaymentMethod());
    System.out.println("  Transaction ID: " + payment.getTransactionId());
    System.out.println("  Amount: " + payment.getAmount());
    
    String insertSQL = "INSERT INTO payments (" +
            "order_id, payment_method, amount, phone_number, " +
            "sender_name, account_number, transaction_id, status, payment_date" +
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
        
        // Required fields
        pstmt.setInt(1, payment.getOrderId());
        pstmt.setString(2, payment.getPaymentMethod()); // This is now guaranteed not null
        pstmt.setDouble(3, payment.getAmount());
        pstmt.setString(7, payment.getTransactionId()); // This is now guaranteed not null
        pstmt.setString(8, payment.getStatus() != null ? payment.getStatus() : "Completed");
        pstmt.setTimestamp(9, new Timestamp(payment.getPaymentDate().getTime()));
        
        // Optional fields - handle null values
        if (payment.getPhoneNumber() != null && !payment.getPhoneNumber().trim().isEmpty()) {
            pstmt.setString(4, payment.getPhoneNumber().trim());
        } else {
            pstmt.setNull(4, Types.VARCHAR);
        }
        
        if (payment.getSenderName() != null && !payment.getSenderName().trim().isEmpty()) {
            pstmt.setString(5, payment.getSenderName().trim());
        } else {
            pstmt.setNull(5, Types.VARCHAR);
        }
        
        if (payment.getAccountNumber() != null && !payment.getAccountNumber().trim().isEmpty()) {
            pstmt.setString(6, payment.getAccountNumber().trim());
        } else {
            pstmt.setNull(6, Types.VARCHAR);
        }
        
        int rowsAffected = pstmt.executeUpdate();
        System.out.println("Rows affected: " + rowsAffected);
        
        if (rowsAffected > 0) {
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int paymentId = generatedKeys.getInt(1);
                payment.setPaymentId(paymentId);
                System.out.println("Payment saved with ID: " + paymentId);
            }
            return true;
        }
        return false;
        
    } catch (SQLException e) {
        System.err.println("SQL Error saving payment: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}    
        
    // Alternative method that returns the generated payment ID
    public int savePaymentReturnId(Payment payment) {
        String insertSQL = "INSERT INTO payments (" +
                "order_id, payment_method, amount, phone_number, " +
                "sender_name, account_number, transaction_id, status, payment_date" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, payment.getOrderId());
            pstmt.setString(2, payment.getPaymentMethod());
            pstmt.setDouble(3, payment.getAmount());
            
            // Handle nullable fields
            if (payment.getPhoneNumber() != null && !payment.getPhoneNumber().isEmpty()) {
                pstmt.setString(4, payment.getPhoneNumber());
            } else {
                pstmt.setNull(4, Types.VARCHAR);
            }
            
            if (payment.getSenderName() != null && !payment.getSenderName().isEmpty()) {
                pstmt.setString(5, payment.getSenderName());
            } else {
                pstmt.setNull(5, Types.VARCHAR);
            }
            
            if (payment.getAccountNumber() != null && !payment.getAccountNumber().isEmpty()) {
                pstmt.setString(6, payment.getAccountNumber());
            } else {
                pstmt.setNull(6, Types.VARCHAR);
            }
            
            pstmt.setString(7, payment.getTransactionId());
            pstmt.setString(8, payment.getStatus());
            pstmt.setTimestamp(9, new Timestamp(payment.getPaymentDate().getTime()));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int paymentId = generatedKeys.getInt(1);
                    payment.setPaymentId(paymentId);
                    return paymentId;
                }
            }
            return -1;
            
        } catch (SQLException e) {
            System.err.println("Error saving payment: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
    
    // Update payment status
    public boolean updatePaymentStatus(String transactionId, String status) {
        String updateSQL = "UPDATE payments SET status = ? WHERE transaction_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
            
            pstmt.setString(1, status);
            pstmt.setString(2, transactionId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
            return false;
        }
    }
    
    // Get payment by transaction ID
    public Payment getPaymentByTransactionId(String transactionId) {
        String selectSQL = "SELECT * FROM payments WHERE transaction_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {
            
            pstmt.setString(1, transactionId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToPayment(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting payment: " + e.getMessage());
        }
        return null;
    }
    
    // Get all payments for a customer (via orders)
    public List<Payment> getCustomerPayments(int customerId) {
        List<Payment> payments = new ArrayList<>();
        String selectSQL = "SELECT p.* FROM payments p " +
                          "INNER JOIN orders o ON p.order_id = o.order_id " +
                          "WHERE o.customer_id = ? ORDER BY p.payment_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {
            
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                payments.add(mapResultSetToPayment(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting customer payments: " + e.getMessage());
        }
        return payments;
    }
    
    // Get payments by order ID
    public List<Payment> getPaymentsByOrderId(int orderId) {
        List<Payment> payments = new ArrayList<>();
        String selectSQL = "SELECT * FROM payments WHERE order_id = ? ORDER BY payment_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {
            
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                payments.add(mapResultSetToPayment(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting payments by order: " + e.getMessage());
        }
        return payments;
    }
    
    // Helper method to map ResultSet to Payment object
    private Payment mapResultSetToPayment(ResultSet rs) throws SQLException {
        Payment payment = new Payment();
        payment.setPaymentId(rs.getInt("payment_id"));
        payment.setOrderId(rs.getInt("order_id"));
        payment.setPaymentMethod(rs.getString("payment_method"));
        payment.setAmount(rs.getDouble("amount"));
        payment.setPhoneNumber(rs.getString("phone_number"));
        payment.setSenderName(rs.getString("sender_name"));
        payment.setAccountNumber(rs.getString("account_number"));
        payment.setTransactionId(rs.getString("transaction_id"));
        payment.setStatus(rs.getString("status"));
        payment.setPaymentDate(rs.getTimestamp("payment_date"));
        payment.setCreatedAt(rs.getTimestamp("created_at"));
        return payment;
    }
    
    // Get total payments amount
    public double getTotalPaymentsAmount() {
        String selectSQL = "SELECT SUM(amount) as total FROM payments WHERE status = 'Completed'";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(selectSQL)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting total payments: " + e.getMessage());
        }
        return 0.0;
    }
    
    // Check if transaction ID already exists
    public boolean transactionIdExists(String transactionId) {
        String checkSQL = "SELECT COUNT(*) as count FROM payments WHERE transaction_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(checkSQL)) {
            
            pstmt.setString(1, transactionId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking transaction ID: " + e.getMessage());
        }
        return false;
    }
}