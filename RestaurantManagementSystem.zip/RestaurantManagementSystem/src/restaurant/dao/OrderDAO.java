package restaurant.dao;

import restaurant.db.DatabaseConnection;
import restaurant.models.Order;
import restaurant.models.OrderItem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    
    public int createOrder(Integer customerId, String customerName, String phoneNumber, 
                          String deliveryAddress, String instructions, byte[] receiptPhoto, 
                          String receiptFilename, String receiptHash, double receiptAmount, 
                          List<OrderItem> orderItems, double totalAmount, boolean deliveryRequired) {
        Connection conn = null;
        PreparedStatement orderStmt = null;
        PreparedStatement itemStmt = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);
            
            String orderSql = "INSERT INTO orders (customer_id, customer_name, phone_number, " +
                            "delivery_address, special_instructions, receipt_photo, receipt_filename, " +
                            "receipt_file_hash, receipt_amount, total_amount, delivery_required) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            orderStmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            
            if (customerId != null) {
                orderStmt.setInt(1, customerId);
            } else {
                orderStmt.setNull(1, Types.INTEGER);
            }
            
            orderStmt.setString(2, customerName);
            orderStmt.setString(3, phoneNumber);
            orderStmt.setString(4, deliveryAddress);
            orderStmt.setString(5, instructions);
            orderStmt.setBytes(6, receiptPhoto);
            orderStmt.setString(7, receiptFilename);
            orderStmt.setString(8, receiptHash);
            orderStmt.setDouble(9, receiptAmount);
            orderStmt.setDouble(10, totalAmount);
            orderStmt.setBoolean(11, deliveryRequired);
            
            int affectedRows = orderStmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }
            
            generatedKeys = orderStmt.getGeneratedKeys();
            int orderId;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }
            
            String itemSql = "INSERT INTO order_items (order_id, item_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
            itemStmt = conn.prepareStatement(itemSql);
            
            for (OrderItem orderItem : orderItems) {
                itemStmt.setInt(1, orderId);
                itemStmt.setInt(2, orderItem.getMenuItem().getItemId());
                itemStmt.setInt(3, orderItem.getQuantity());
                itemStmt.setDouble(4, orderItem.getMenuItem().getPrice());
                itemStmt.addBatch();
            }
            
            itemStmt.executeBatch();
            
            if (customerId != null) {
                CustomerDAO customerDAO = new CustomerDAO();
                customerDAO.updateCustomerStats(customerId, totalAmount);
            }
            
            conn.commit();
            return orderId;
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return -1;
        } finally {
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (orderStmt != null) orderStmt.close();
                if (itemStmt != null) itemStmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public List<Order> getOrdersByCustomer(int customerId) {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders WHERE customer_id = ? ORDER BY order_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Order order = new Order(
                    rs.getInt("order_id"),
                    rs.getInt("customer_id"),
                    rs.getString("customer_name"),
                    rs.getString("phone_number"),
                    rs.getString("delivery_address"),
                    rs.getString("special_instructions"),
                    rs.getBytes("receipt_photo"),
                    rs.getString("receipt_filename"),
                    rs.getString("receipt_file_hash"),
                    rs.getDouble("receipt_amount"),
                    rs.getDouble("total_amount"),
                    rs.getBoolean("delivery_required"),
                    rs.getTimestamp("order_date"),
                    rs.getString("receipt_status"),
                    rs.getString("rejection_reason")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    public boolean updateOrderStatus(int orderId, String status, String reason) {
        String query = "UPDATE orders SET receipt_status = ?, rejection_reason = ? WHERE order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, status);
            pstmt.setString(2, reason);
            pstmt.setInt(3, orderId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders ORDER BY order_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Order order = new Order(
                    rs.getInt("order_id"),
                    rs.getInt("customer_id"),
                    rs.getString("customer_name"),
                    rs.getString("phone_number"),
                    rs.getString("delivery_address"),
                    rs.getString("special_instructions"),
                    rs.getBytes("receipt_photo"),
                    rs.getString("receipt_filename"),
                    rs.getString("receipt_file_hash"),
                    rs.getDouble("receipt_amount"),
                    rs.getDouble("total_amount"),
                    rs.getBoolean("delivery_required"),
                    rs.getTimestamp("order_date"),
                    rs.getString("receipt_status"),
                    rs.getString("rejection_reason")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}