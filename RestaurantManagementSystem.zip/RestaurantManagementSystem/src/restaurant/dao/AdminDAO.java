package restaurant.dao;

import restaurant.models.Admin;
import restaurant.models.MenuItem;
import restaurant.models.Order;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import restaurant.db.DatabaseConnection;
import restaurant.models.Customer;

public class AdminDAO {
    
    public Admin loginAdmin(String username, String password) {
        String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Admin(
                    rs.getInt("admin_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("full_name"),
                    rs.getString("role")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // MENU MANAGEMENT
    public boolean addMenuItem(MenuItem item) {
        String query = "INSERT INTO menu_items (category_id, item_name, description, price, available) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, item.getCategoryId());
            pstmt.setString(2, item.getItemName());
            pstmt.setString(3, item.getDescription());
            pstmt.setDouble(4, item.getPrice());
            pstmt.setBoolean(5, item.isAvailable());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean updateMenuItem(MenuItem item) {
        String query = "UPDATE menu_items SET category_id=?, item_name=?, description=?, price=?, available=? WHERE item_id=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, item.getCategoryId());
            pstmt.setString(2, item.getItemName());
            pstmt.setString(3, item.getDescription());
            pstmt.setDouble(4, item.getPrice());
            pstmt.setBoolean(5, item.isAvailable());
            pstmt.setInt(6, item.getItemId());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteMenuItem(int itemId) {
        String query = "DELETE FROM menu_items WHERE item_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, itemId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // ORDER MANAGEMENT
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders ORDER BY order_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Order order = new Order(
                    rs.getInt("order_id"),
                    rs.getInt("customer_id"),
                    rs.getString("customer_name"),
                    rs.getString("phone_number"),
                    rs.getString("delivery_address"),
                    rs.getString("special_instructions"),
                    rs.getBytes("receipt_photo"),
                    rs.getString("receipt_filename"),
                    rs.getString("receipt_file_hash"),
                    rs.getDouble("receipt_amount"),
                    rs.getDouble("total_amount"),
                    rs.getBoolean("delivery_required"),
                    rs.getTimestamp("order_date"),
                    rs.getString("receipt_status"),
                    rs.getString("rejection_reason")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    public boolean updateOrderStatus(int orderId, String status, String reason) {
        String query = "UPDATE orders SET receipt_status = ?, rejection_reason = ? WHERE order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, status);
            pstmt.setString(2, reason);
            pstmt.setInt(3, orderId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // CUSTOMER MANAGEMENT
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM customers ORDER BY registration_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Customer customer = new Customer(
                    rs.getInt("customer_id"),
                    rs.getString("phone_number"),
                    null, // password not needed for admin view
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("address"),
                    rs.getString("customer_type"),
                    rs.getTimestamp("registration_date"),
                    rs.getInt("total_orders"),
                    rs.getDouble("total_spent")
                );
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }
    
    // SALES REPORTS
    public double getTotalRevenue() {
        String query = "SELECT SUM(total_amount) as total FROM orders WHERE receipt_status = 'APPROVED'";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }
    
    public int getTotalOrders() {
        String query = "SELECT COUNT(*) as total FROM orders";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}