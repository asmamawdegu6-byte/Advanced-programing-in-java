package restaurant.models;

public class Admin {
    private int adminId;
    private String username;
    private String password;
    private String fullName;
    private String role;
    
    public Admin(int adminId, String username, String password, String fullName, String role) {
        this.adminId = adminId;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }
    
    // Getters
    public int getAdminId() { 
        return adminId; 
    }
    
    public String getUsername() { 
        return username; 
    }
    
    public String getPassword() { 
        return password; 
    }
    
    public String getFullName() { 
        return fullName; 
    }
    
    public String getRole() { 
        return role; 
    }
    
    // Setters
    public void setAdminId(int adminId) { 
        this.adminId = adminId; 
    }
    
    public void setUsername(String username) { 
        this.username = username; 
    }
    
    public void setPassword(String password) { 
        this.password = password; 
    }
    
    public void setFullName(String fullName) { 
        this.fullName = fullName; 
    }
    
    public void setRole(String role) { 
        this.role = role; 
    }
    
    @Override
    public String toString() {
        return String.format("Admin{id=%d, name='%s', role='%s'}", adminId, role);
    }
}