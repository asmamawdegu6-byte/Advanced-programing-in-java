package restaurant.models;

import java.sql.Timestamp;
import java.util.Date;

public class Customer {
    private int customerId;
    private String phoneNumber;
    private String password;
    private String fullName;
    private String email;
    private String address;
    private String customerType;
    private Timestamp registrationDate;
    private int totalOrders;
    private double totalSpent;
    
    // Constructor with all parameters
    public Customer(int customerId, String phoneNumber, String password, String fullName, 
                   String email, String address, String customerType, 
                   Timestamp registrationDate, int totalOrders, double totalSpent) {
        this.customerId = customerId;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
        this.address = address;
        this.customerType = customerType;
        this.registrationDate = registrationDate;
        this.totalOrders = totalOrders;
        this.totalSpent = totalSpent;
    }

    // Empty/default constructor
    public Customer() {
        this.customerId = 0;
        this.phoneNumber = "";
        this.password = "";
        this.fullName = "";
        this.email = "";
        this.address = "";
        this.customerType = "GUEST";
        this.registrationDate = new Timestamp(new Date().getTime());
        this.totalOrders = 0;
        this.totalSpent = 0.0;
    }
    
    // Constructor for guest customers
    public Customer(String fullName, String phoneNumber) {
        this.customerId = 0;
        this.phoneNumber = phoneNumber;
        this.password = "";
        this.fullName = fullName;
        this.email = "";
        this.address = "";
        this.customerType = "GUEST";
        this.registrationDate = new Timestamp(new Date().getTime());
        this.totalOrders = 0;
        this.totalSpent = 0.0;
    }
    
    // Getters
    public int getCustomerId() { 
        return customerId; 
    }
    
    public String getPhoneNumber() { 
        return phoneNumber; 
    }
    
    public String getPassword() { 
        return password; 
    }
    
    public String getFullName() { 
        return fullName; 
    }
    
    public String getEmail() { 
        return email; 
    }
    
    public String getAddress() { 
        return address; 
    }
    
    public String getCustomerType() { 
        return customerType; 
    }
    
    public Timestamp getRegistrationDate() { 
        return registrationDate; 
    }
    
    public int getTotalOrders() { 
        return totalOrders; 
    }
    
    public double getTotalSpent() { 
        return totalSpent; 
    }
    
    // Setters
    public void setCustomerId(int customerId) { 
        this.customerId = customerId; 
    }
    
    public void setPhoneNumber(String phoneNumber) { 
        if (phoneNumber != null) {
            this.phoneNumber = phoneNumber;
        } else {
            this.phoneNumber = "";
        }
    }
    
    public void setPassword(String password) { 
        if (password != null) {
            this.password = password;
        } else {
            this.password = "";
        }
    }
    
    public void setFullName(String fullName) { 
        if (fullName != null) {
            this.fullName = fullName;
        } else {
            this.fullName = "";
        }
    }
    
    public void setEmail(String email) { 
        if (email != null) {
            this.email = email;
        } else {
            this.email = "";
        }
    }
    
    public void setAddress(String address) { 
        if (address != null) {
            this.address = address;
        } else {
            this.address = "";
        }
    }
    
    public void setCustomerType(String customerType) { 
        if (customerType != null) {
            this.customerType = customerType;
        } else {
            this.customerType = "GUEST";
        }
    }
    
    public void setRegistrationDate(Timestamp registrationDate) { 
        if (registrationDate != null) {
            this.registrationDate = registrationDate;
        } else {
            this.registrationDate = new Timestamp(new Date().getTime());
        }
    }
    
    public void setTotalOrders(int totalOrders) { 
        this.totalOrders = totalOrders >= 0 ? totalOrders : 0;
    }
    
    public void setTotalSpent(double totalSpent) { 
        this.totalSpent = totalSpent >= 0.0 ? totalSpent : 0.0;
    }
    
    // Helper methods
    public void incrementOrders(double orderAmount) {
        this.totalOrders++;
        this.totalSpent += orderAmount;
    }
    
    public boolean isRegistered() {
        return "REGISTERED".equalsIgnoreCase(customerType);
    }
    
    public boolean isGuest() {
        return "GUEST".equalsIgnoreCase(customerType);
    }
    
    public String getCustomerTypeDisplay() {
        if (customerType == null) return "Guest";
        switch(customerType.toUpperCase()) {
            case "REGISTERED": return "Registered Customer";
            case "GUEST": return "Guest Customer";
            case "VIP": return "VIP Customer";
            case "REGULAR": return "Regular Customer";
            default: return customerType;
        }
    }
    
    public String getFormattedTotalSpent() {
        return String.format("$%.2f", totalSpent);
    }
    
    public String getFormattedRegistrationDate() {
        if (registrationDate == null) return "N/A";
        return String.format("%1$tY-%1$tm-%1$td", registrationDate);
    }
    
    public boolean hasValidPhone() {
        return phoneNumber != null && phoneNumber.matches("^09[0-9]{8}$");
    }
    
    public boolean hasValidEmail() {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }
    
    public void validateAndClean() {
        if (fullName == null) fullName = "";
        if (phoneNumber == null) phoneNumber = "";
        if (password == null) password = "";
        if (email == null) email = "";
        if (address == null) address = "";
        if (customerType == null) customerType = "GUEST";
        
        // Trim all strings
        fullName = fullName.trim();
        phoneNumber = phoneNumber.trim();
        email = email.trim();
        address = address.trim();
        customerType = customerType.trim().toUpperCase();
        
        // Set default values if empty
        if (fullName.isEmpty()) fullName = "Guest Customer";
        if (customerType.isEmpty()) customerType = "GUEST";
    }
    
    @Override
    public String toString() {
        return String.format("Customer{id=%d, name='%s', phone='%s', type='%s', orders=%d, spent=%.2f}", 
            customerId, fullName, phoneNumber, customerType, totalOrders, totalSpent);
    }
    
    // Additional utility method for display
    public String getSummary() {
        return String.format("%s (%s) - %s", 
            fullName, 
            phoneNumber, 
            getCustomerTypeDisplay());
    }
}