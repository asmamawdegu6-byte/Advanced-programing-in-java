package restaurant.models;

import java.sql.Timestamp;

public class Order {
    private int orderId;
    private int customerId;
    private String customerName;
    private String phoneNumber;
    private String deliveryAddress;
    private String specialInstructions;
    private byte[] receiptPhoto;
    private String receiptFilename;
    private String receiptFileHash;
    private double receiptAmount;
    private double totalAmount;
    private boolean deliveryRequired;
    private Timestamp orderDate;
    private String receiptStatus;
    private String rejectionReason;
    
    public Order(int orderId, int customerId, String customerName, String phoneNumber,
                String deliveryAddress, String specialInstructions, byte[] receiptPhoto,
                String receiptFilename, String receiptFileHash, double receiptAmount,
                double totalAmount, boolean deliveryRequired, Timestamp orderDate,
                String receiptStatus, String rejectionReason) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.deliveryAddress = deliveryAddress;
        this.specialInstructions = specialInstructions;
        this.receiptPhoto = receiptPhoto;
        this.receiptFilename = receiptFilename;
        this.receiptFileHash = receiptFileHash;
        this.receiptAmount = receiptAmount;
        this.totalAmount = totalAmount;
        this.deliveryRequired = deliveryRequired;
        this.orderDate = orderDate;
        this.receiptStatus = receiptStatus;
        this.rejectionReason = rejectionReason;
    }
    
    // Getters
    public int getOrderId() { return orderId; }
    public int getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public String getSpecialInstructions() { return specialInstructions; }
    public byte[] getReceiptPhoto() { return receiptPhoto; }
    public String getReceiptFilename() { return receiptFilename; }
    public String getReceiptFileHash() { return receiptFileHash; }
    public double getReceiptAmount() { return receiptAmount; }
    public double getTotalAmount() { return totalAmount; }
    public boolean isDeliveryRequired() { return deliveryRequired; }
    public Timestamp getOrderDate() { return orderDate; }
    public String getReceiptStatus() { return receiptStatus; }
    public String getRejectionReason() { return rejectionReason; }
}