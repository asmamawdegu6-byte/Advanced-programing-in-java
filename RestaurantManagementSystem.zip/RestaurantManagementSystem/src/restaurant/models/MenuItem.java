package restaurant.models;

public class MenuItem {
    private int itemId;
    private int categoryId;
    private String itemName;
    private String description;
    private double price;
    private boolean available;
    
    public MenuItem(int itemId, int categoryId, String itemName, String description, double price, boolean available) {
        this.itemId = itemId;
        this.categoryId = categoryId;
        this.itemName = itemName;
        this.description = description;
        this.price = price;
        this.available = available;
    }

   
    
    // Getters
    public int getItemId() { 
        return itemId; 
    }
    
    public int getCategoryId() { 
        return categoryId; 
    }
    
    public String getItemName() { 
        return itemName; 
    }
    
    public String getDescription() { 
        return description; 
    }
    
    public double getPrice() { 
        return price; 
    }
    
    public boolean isAvailable() { 
        return available; 
    }
    
    // Setters
    public void setItemId(int itemId) { 
        this.itemId = itemId; 
    }
    
    public void setCategoryId(int categoryId) { 
        this.categoryId = categoryId; 
    }
    
    public void setItemName(String itemName) { 
        this.itemName = itemName; 
    }
    
    public void setDescription(String description) { 
        this.description = description; 
    }
    
    public void setPrice(double price) { 
        this.price = price; 
    }
    
    public void setAvailable(boolean available) { 
        this.available = available; 
    }
    
    @Override
    public String toString() {
        return String.format("%s - $%.2f", itemName, price);
    }
}