package restaurant.models;

public class OrderItem {
    private MenuItem menuItem;
    private int quantity;
    
    public OrderItem() {
        // Default constructor
        this.quantity = 1;
    }
    
    public OrderItem(MenuItem menuItem, int quantity) {
        this.menuItem = menuItem;
        this.quantity = quantity;
    }
    
    // Getters
    public MenuItem getMenuItem() {
        return menuItem;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    // Setters
    public void setMenuItem(MenuItem menuItem) {
        this.menuItem = menuItem;
    }
    
    public void setQuantity(int quantity) {
        if (quantity > 0) {
            this.quantity = quantity;
        }
    }
    
    // Business logic methods
    public double getSubtotal() {
        if (menuItem == null) {
            return 0.0;
        }
        return menuItem.getPrice() * quantity;
    }
    
    public void increaseQuantity() {
        quantity++;
    }
    
    public void decreaseQuantity() {
        if (quantity > 1) {
            quantity--;
        }
    }
    
    public String getItemName() {
        return menuItem != null ? menuItem.getItemName() : "Unknown Item";
    }
    
    public double getUnitPrice() {
        return menuItem != null ? menuItem.getPrice() : 0.0;
    }
    
    @Override
    public String toString() {
        if (menuItem == null) {
            return "OrderItem{menuItem=null, quantity=" + quantity + "}";
        }
        return String.format("%s x%d = $%.2f", menuItem.getItemName(), quantity, getSubtotal());
    }
    
    // Helper method for display
    public String toDisplayString() {
        if (menuItem == null) {
            return "Unknown Item x" + quantity;
        }
        return String.format("%-25s x%-3d $%-7.2f $%-9.2f", 
            menuItem.getItemName(), 
            quantity, 
            menuItem.getPrice(), 
            getSubtotal());
    }
}