package restaurant.validation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class ReceiptValidator {
    
    private static Map<String, String> fileHashes = new HashMap<>();
    
    public static ValidationResult validateReceipt(File receiptFile, double orderAmount, 
                                                 String restaurantName) {
        ValidationResult result = new ValidationResult();
        
        // Step 1: File Hash Check (Duplicate Detection)
        String fileHash = calculateFileHash(receiptFile);
        if (fileHash == null) {
            result.setStatus("REJECTED");
            result.setReason("Invalid file - cannot read receipt");
            return result;
        }
        
        if (fileHashes.containsKey(fileHash)) {
            result.setStatus("REJECTED");
            result.setReason("Duplicate receipt detected - already used in another order");
            return result;
        }
        
        // Step 2: File Type and Size Validation
        if (!isValidFileType(receiptFile)) {
            result.setStatus("REJECTED");
            result.setReason("Invalid file type. Only JPG, PNG, JPEG allowed");
            return result;
        }
        
        if (!isValidFileSize(receiptFile)) {
            result.setStatus("REJECTED");
            result.setReason("File too large. Maximum 5MB allowed");
            return result;
        }
        
        // Step 3: Amount Match Check (±$0.10 tolerance)
        if (!isAmountMatching(orderAmount, orderAmount)) {
            result.setStatus("REJECTED");
            result.setReason("Receipt amount does not match order total");
            return result;
        }
        
        // Step 4: Date Match Check (Always 24hr business)
        if (!isDateValid()) {
            result.setStatus("REJECTED");
            result.setReason("Receipt date is not valid");
            return result;
        }
        
        // Step 5: Restaurant Name Check
        if (!isRestaurantMatching(restaurantName, "Group 5 Restaurant")) {
            result.setStatus("REJECTED");
            result.setReason("Receipt not from our restaurant");
            return result;
        }
        
        // All validations passed
        fileHashes.put(fileHash, new java.util.Date().toString());
        result.setStatus("APPROVED");
        result.setReason("Receipt validated successfully");
        result.setFileHash(fileHash);
        
        return result;
    }
    
    public static String calculateFileHash(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int bytesRead;
            
            while ((bytesRead = fis.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
            
            byte[] hash = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
            
        } catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private static boolean isValidFileType(File file) {
        String name = file.getName().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png");
    }
    
    private static boolean isValidFileSize(File file) {
        long sizeInMB = file.length() / (1024 * 1024);
        return sizeInMB <= 5;
    }
    
    private static boolean isAmountMatching(double receiptAmount, double orderAmount) {
        double difference = Math.abs(receiptAmount - orderAmount);
        return difference <= 0.10;
    }
    
    private static boolean isDateValid() {
        return true; // Always valid for 24hr business
    }
    
    private static boolean isRestaurantMatching(String receiptRestaurant, String ourRestaurant) {
        return true; // Assume valid for project
    }
    
    public static class ValidationResult {
        private String status;
        private String reason;
        private String fileHash;
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getReason() { return reason; }
        public void setReason(String reason) { this.reason = reason; }
        public String getFileHash() { return fileHash; }
        public void setFileHash(String fileHash) { this.fileHash = fileHash; }
        
        public boolean isValid() {
            return "APPROVED".equals(status);
        }
    }
}