package restaurant.validation;

import java.util.regex.Pattern;

public class InputValidator {
    
    private static final Pattern PHONE_PATTERN = Pattern.compile("^09[0-9]{8}$");
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z ]{2,50}$");
    
    public static ValidationResult validatePhoneNumber(String phone) {
        ValidationResult result = new ValidationResult();
        
        if (phone == null || phone.trim().isEmpty()) {
            result.setValid(false);
            result.setMessage("Phone number is required");
            return result;
        }
        
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            result.setValid(false);
            result.setMessage("Phone number must be 10 digits starting with 09");
            return result;
        }
        
        result.setValid(true);
        result.setMessage("Valid phone number");
        return result;
    }
    
    public static ValidationResult validateName(String name) {
        ValidationResult result = new ValidationResult();
        
        if (name == null || name.trim().isEmpty()) {
            result.setValid(false);
            result.setMessage("Name is required");
            return result;
        }
        
        if (!NAME_PATTERN.matcher(name).matches()) {
            result.setValid(false);
            result.setMessage("Name must be 2-50 letters and spaces only");
            return result;
        }
        
        result.setValid(true);
        result.setMessage("Valid name");
        return result;
    }
    
    public static ValidationResult validatePassword(String password) {
        ValidationResult result = new ValidationResult();
        
        if (password == null || password.length() < 4) {
            result.setValid(false);
            result.setMessage("Password must be at least 4 characters");
            return result;
        }
        
        result.setValid(true);
        result.setMessage("Valid password");
        return result;
    }
    
    public static class ValidationResult {
        private boolean valid;
        private String message;
        
        public boolean isValid() { return valid; }
        public void setValid(boolean valid) { this.valid = valid; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
}