package restaurant.gui;

import restaurant.dao.PaymentDAO;
import restaurant.models.Payment;
import java.text.SimpleDateFormat;
import java.util.Random;
import restaurant.dao.CategoryDAO;
import restaurant.dao.MenuDAO;
import restaurant.dao.OrderDAO;
import restaurant.models.Customer;
import restaurant.models.MenuItem;
import restaurant.models.OrderItem;
import restaurant.validation.ReceiptValidator;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RestaurantManagementSystem extends JFrame {
    private Customer currentCustomer;
    private List<OrderItem> currentOrderItems;
    private JTextArea orderSummaryArea;
    private JLabel totalAmountLabel;
    private double totalAmount;
    private File receiptPhotoFile;
    private Map<String, JButton> categoryButtons;
    private JTextField searchField;
    private JComboBox<String> filterCombo;
    private JTable searchTable;
    private DefaultTableModel tableModel;
    private List<MenuItem> allMenuItems;
    private Payment currentPayment;
    private String selectedPaymentMethod;
    private JFrame loginFrame;
    
    public RestaurantManagementSystem(Customer customer, JFrame loginFrame) {
        this.currentCustomer = customer;
        this.currentOrderItems = new ArrayList<>();
        this.totalAmount = 0.00;
        this.categoryButtons = new HashMap<>();
        this.totalAmountLabel = new JLabel("Total: ETB 0.00");
        this.allMenuItems = new ArrayList<>();
        this.currentPayment = null;
        this.loginFrame = loginFrame;
        initializePaymentDatabase();
        initializeUI();
        loadAllMenuItems();
    }
    
    public RestaurantManagementSystem(Customer customer) {
        this(customer, null);
    }
    
    private void initializePaymentDatabase() {
        try {
            PaymentDAO paymentDAO = new PaymentDAO();
            paymentDAO.createPaymentsTable();
            System.out.println("Payment database initialized successfully.");
        } catch (Exception e) {
            System.err.println("Error initializing payment database: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                "Warning: Payment system database initialization failed.\n" +
                "Some payment features may not work correctly.",
                "Database Warning",
                JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void initializeUI() {
        setTitle("Restaurant Management System - " + currentCustomer.getFullName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        tabbedPane.addTab("🏠 Home", createHomePanel());
        tabbedPane.addTab("🍽️ Menu", createMenuPanel());
        tabbedPane.addTab("🔍 Search Items", createSearchPanel());
        tabbedPane.addTab("🛒 Order", createOrderPanel());
        tabbedPane.addTab("💳 Payment", createPaymentPanel());
        
        add(tabbedPane);
    }
    
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));
        
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel welcomeLabel = new JLabel("Welcome to Our Restaurant System", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setForeground(new Color(70, 130, 180));
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> logout());
        
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        headerPanel.add(logoutBtn, BorderLayout.EAST);
        
        JTextArea infoArea = new JTextArea();
        infoArea.setText("\n\nWelcome: " + 
                        currentCustomer.getFullName() + " (" + currentCustomer.getCustomerType() + " Customer)" +
                        "\n\nPhone: " + currentCustomer.getPhoneNumber() +
                        "\nEmail: " + currentCustomer.getEmail() +
                        "\nAddress: " + currentCustomer.getAddress() +
                        "\nTotal Orders: " + currentCustomer.getTotalOrders() +
                        "\nTotal Spent: ETB " + String.format("%.2f", currentCustomer.getTotalSpent()));
        infoArea.setEditable(false);
        infoArea.setFont(new Font("Arial", Font.PLAIN, 14));
        infoArea.setBackground(new Color(240, 248, 255));
        infoArea.setMargin(new Insets(20, 20, 20, 20));
        
        JScrollPane scrollPane = new JScrollPane(infoArea);
        scrollPane.setBorder(null);
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(240, 248, 255));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        JButton backToLoginBtn = new JButton("← Back to Login Screen");
        backToLoginBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backToLoginBtn.setBackground(new Color(70, 130, 180));
        backToLoginBtn.setForeground(Color.WHITE);
        backToLoginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backToLoginBtn.setPreferredSize(new Dimension(200, 40));
        backToLoginBtn.addActionListener(e -> backToLogin());
        
        bottomPanel.add(backToLoginBtn);
        
        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createMenuPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 3, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(240, 248, 255));
        
        String[][] categories = {
            {"Breakfast", "1"},
            {"Lunch", "2"}, 
            {"Dinner", "3"},
            {"Alcoholic Drinks", "4"},
            {"Mocktails & Soft Drinks", "5"},
            {"Fresh Juice", "6"},
            {"Hot Drinks", "7"},
            {"Sweet Food", "8"},
            {"Vegetables", "9"}
        };
        
        for (String[] categoryInfo : categories) {
            String categoryName = categoryInfo[0];
            final String categoryId = categoryInfo[1];
            
            JButton btn = new JButton("<html><center>" + categoryName + "</center></html>");
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(70, 130, 180));
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                BorderFactory.createEmptyBorder(15, 5, 15, 5)
            ));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            categoryButtons.put(categoryName, btn);
            
            btn.addActionListener(e -> {
                showCategoryItems(categoryName, Integer.parseInt(categoryId));
            });
            
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new Color(100, 149, 237));
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new Color(70, 130, 180));
                }
            });
            
            panel.add(btn);
        }
        
        return panel;
    }
    
    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel searchControlsPanel = new JPanel();
        searchControlsPanel.setLayout(new BoxLayout(searchControlsPanel, BoxLayout.Y_AXIS));
        searchControlsPanel.setBackground(new Color(240, 248, 255));
        searchControlsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180), 2),
            "Search & Filter Menu Items"
        ));
        
        JPanel searchRowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchRowPanel.setBackground(new Color(240, 248, 255));
        
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Arial", Font.BOLD, 14));
        searchLabel.setForeground(new Color(70, 130, 180));
        
        searchField = new JTextField(25);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchField.setToolTipText("Search by item name, description, or price");
        
        JButton searchButton = new JButton("🔍 Search");
        searchButton.setBackground(new Color(70, 130, 180));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        JButton clearButton = new JButton("Clear");
        clearButton.setBackground(new Color(169, 169, 169));
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        searchRowPanel.add(searchLabel);
        searchRowPanel.add(searchField);
        searchRowPanel.add(searchButton);
        searchRowPanel.add(clearButton);
        
        JPanel filterRowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        filterRowPanel.setBackground(new Color(240, 248, 255));
        
        JLabel filterLabel = new JLabel("Filter By:");
        filterLabel.setFont(new Font("Arial", Font.BOLD, 14));
        filterLabel.setForeground(new Color(70, 130, 180));
        
        filterCombo = new JComboBox<>(new String[]{
            "All Items", 
            "Name", 
            "Category", 
            "Price Range", 
            "Available Only",
            "Vegetarian",
            "Non-Vegetarian"
        });
        filterCombo.setFont(new Font("Arial", Font.PLAIN, 13));
        filterCombo.setPreferredSize(new Dimension(150, 30));
        
        JPanel priceRangePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        priceRangePanel.setBackground(new Color(240, 248, 255));
        priceRangePanel.setVisible(false);
        
        JLabel minPriceLabel = new JLabel("Min:");
        JTextField minPriceField = new JTextField(5);
        minPriceField.setText("0");
        
        JLabel maxPriceLabel = new JLabel("Max:");
        JTextField maxPriceField = new JTextField(5);
        maxPriceField.setText("1000");
        
        priceRangePanel.add(minPriceLabel);
        priceRangePanel.add(minPriceField);
        priceRangePanel.add(Box.createHorizontalStrut(10));
        priceRangePanel.add(maxPriceLabel);
        priceRangePanel.add(maxPriceField);
        
        filterCombo.addActionListener(e -> {
            String selected = (String) filterCombo.getSelectedItem();
            priceRangePanel.setVisible("Price Range".equals(selected));
        });
        
        filterRowPanel.add(filterLabel);
        filterRowPanel.add(filterCombo);
        filterRowPanel.add(priceRangePanel);
        
        searchControlsPanel.add(searchRowPanel);
        searchControlsPanel.add(Box.createVerticalStrut(10));
        searchControlsPanel.add(filterRowPanel);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            "Search Results"
        ));
        tablePanel.setBackground(Color.WHITE);
        
        String[] columns = {"ID", "Item Name", "Price (ETB)", "Category", "Available", "Description", "Add"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6;
            }
        };
        
        searchTable = new JTable(tableModel);
        customizeSearchTable();
        
        JScrollPane scrollPane = new JScrollPane(searchTable);
        scrollPane.setPreferredSize(new Dimension(0, 400));
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        searchButton.addActionListener(e -> performSearch(minPriceField, maxPriceField));
        
        clearButton.addActionListener(e -> {
            searchField.setText("");
            filterCombo.setSelectedIndex(0);
            minPriceField.setText("0");
            maxPriceField.setText("1000");
            priceRangePanel.setVisible(false);
            loadAllMenuItemsToTable();
            searchTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer());
            searchTable.repaint();
        });
        
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (!searchField.getText().trim().isEmpty()) {
                    performSearch(minPriceField, maxPriceField);
                } else {
                    loadAllMenuItemsToTable();
                }
            }
        });
        
        panel.add(searchControlsPanel, BorderLayout.NORTH);
        panel.add(tablePanel, BorderLayout.CENTER);
        
        loadAllMenuItemsToTable();
        
        return panel;
    }
    
    private JPanel createPaymentPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(new Color(240, 248, 255));
        
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(139, 0, 0));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("💳 PAYMENT GATEWAY", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel amountLabel = new JLabel("Total: ETB " + String.format("%.2f", totalAmount));
        amountLabel.setFont(new Font("Arial", Font.BOLD, 16));
        amountLabel.setForeground(Color.YELLOW);
        
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(amountLabel, BorderLayout.EAST);
        
        JPanel methodsPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        methodsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 0, 0), 2),
            "Select Payment Method"
        ));
        methodsPanel.setBackground(Color.WHITE);
        methodsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JButton telebirrBtn = createPaymentMethodButton("📱 TELEBIRR", 
            new Color(0, 128, 0), "TeleBirr.png");
        telebirrBtn.addActionListener(e -> showTeleBirrPaymentDialog());
        
        JButton cbeBirrBtn = createPaymentMethodButton("🏦 CBE BIRR", 
            new Color(25, 25, 112), "cbebirr.png");
        cbeBirrBtn.addActionListener(e -> showCbeBirrPaymentDialog());
        
        JButton bankTransferBtn = createPaymentMethodButton("💼 BANK TRANSFER", 
            new Color(139, 0, 0), "bank.png");
        bankTransferBtn.addActionListener(e -> showBankTransferDialog());
        
        methodsPanel.add(telebirrBtn);
        methodsPanel.add(cbeBirrBtn);
        methodsPanel.add(bankTransferBtn);
        
        JPanel detailsPanel = new JPanel(new BorderLayout());
        detailsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            "Payment Details"
        ));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setPreferredSize(new Dimension(0, 250));
        
        JLabel noSelectionLabel = new JLabel("Please select a payment method above", JLabel.CENTER);
        noSelectionLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        noSelectionLabel.setForeground(Color.GRAY);
        detailsPanel.add(noSelectionLabel, BorderLayout.CENTER);
        
        JPanel historyPanel = new JPanel(new BorderLayout());
        historyPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180), 1),
            "Recent Transactions"
        ));
        historyPanel.setBackground(Color.WHITE);
        historyPanel.setPreferredSize(new Dimension(0, 150));
        
        String[] columns = {"Date", "Method", "Amount", "Status", "Ref No."};
        DefaultTableModel historyModel = new DefaultTableModel(columns, 0);
        JTable historyTable = new JTable(historyModel);
        historyTable.setRowHeight(25);
        
        JScrollPane historyScroll = new JScrollPane(historyTable);
        loadTransactionHistory(historyModel);
        historyPanel.add(historyScroll, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(240, 248, 255));
        
        JButton processPaymentBtn = new JButton("✅ Process Payment");
        processPaymentBtn.setFont(new Font("Arial", Font.BOLD, 14));
        processPaymentBtn.setBackground(new Color(0, 128, 0));
        processPaymentBtn.setForeground(Color.WHITE);
        processPaymentBtn.setEnabled(true);
        processPaymentBtn.addActionListener(e -> processPayment());
        
        JButton cancelPaymentBtn = new JButton("❌ Cancel Payment");
        cancelPaymentBtn.setFont(new Font("Arial", Font.BOLD, 14));
        cancelPaymentBtn.setBackground(new Color(178, 34, 34));
        cancelPaymentBtn.setForeground(Color.WHITE);
        cancelPaymentBtn.addActionListener(e -> cancelPayment());
        
        JButton backToOrderBtn = new JButton("← Back to Order");
        backToOrderBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backToOrderBtn.setBackground(new Color(70, 130, 180));
        backToOrderBtn.setForeground(Color.WHITE);
        backToOrderBtn.addActionListener(e -> {
            JTabbedPane parent = (JTabbedPane) getContentPane().getComponent(0);
            parent.setSelectedIndex(3);
        });
        
        buttonPanel.add(backToOrderBtn);
        buttonPanel.add(cancelPaymentBtn);
        buttonPanel.add(processPaymentBtn);
        
        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(methodsPanel, BorderLayout.CENTER);
        panel.add(detailsPanel, BorderLayout.WEST);
        panel.add(historyPanel, BorderLayout.EAST);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }
    
    private JButton createPaymentMethodButton(String text, Color color, String iconName) {
        JButton button = new JButton();
        
        ImageIcon icon = loadAndResizeIcon(iconName, 50, 50);
        
        if (icon != null) {
            button.setIcon(icon);
            button.setText(text);
            button.setHorizontalTextPosition(SwingConstants.CENTER);
            button.setVerticalTextPosition(SwingConstants.BOTTOM);
            button.setIconTextGap(8);
        } else {
            button.setText(text);
        }
        
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(20, 10, 20, 10)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.brighter());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }

    private ImageIcon loadAndResizeIcon(String iconName, int width, int height) {
        try {
            String[] paths = {
                "images/" + iconName,
                "src/images/" + iconName,
                System.getProperty("user.dir") + "/images/" + iconName
            };
            
            ImageIcon originalIcon = null;
            
            for (String path : paths) {
                File file = new File(path);
                if (file.exists()) {
                    originalIcon = new ImageIcon(path);
                    break;
                }
            }
            
            if (originalIcon == null) {
                URL resource = getClass().getClassLoader().getResource("images/" + iconName);
                if (resource != null) {
                    originalIcon = new ImageIcon(resource);
                }
            }
            
            if (originalIcon == null) {
                System.out.println("Icon not found: " + iconName + ". Using text only.");
                return null;
            }
            
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            
            return new ImageIcon(resizedImage);
            
        } catch (Exception e) {
            System.err.println("Error loading icon '" + iconName + "': " + e.getMessage());
            return null;
        }
    }
    
    private void showTeleBirrPaymentDialog() {
        JDialog dialog = new JDialog(this, "TeleBirr Payment", true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("📱 TeleBirr Payment", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(0, 128, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        gbc.gridwidth = 2;
        gbc.gridy = 1;
        JPanel payToPanel = new JPanel(new BorderLayout());
        payToPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(0, 128, 0), 1),
            "Send To This Number:"
        ));
        payToPanel.setBackground(new Color(240, 255, 240));
        
        JLabel payToLabel = new JLabel("📞 0918915545", JLabel.CENTER);
        payToLabel.setFont(new Font("Arial", Font.BOLD, 24));
        payToLabel.setForeground(new Color(0, 100, 0));
        payToPanel.add(payToLabel, BorderLayout.CENTER);
        panel.add(payToPanel, gbc);
        
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Your Phone Number:"), gbc);
        
        gbc.gridx = 1;
        JTextField phoneField = new JTextField(15);
        phoneField.setText("0918915545");
        panel.add(phoneField, gbc);
        
        gbc.gridy = 3;
        gbc.gridx = 0;
        panel.add(new JLabel("Amount (ETB):"), gbc);
        
        gbc.gridx = 1;
        JTextField amountField = new JTextField(String.format("%.2f", totalAmount));
        amountField.setEditable(false);
        amountField.setBackground(Color.LIGHT_GRAY);
        panel.add(amountField, gbc);
        
        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("TeleBirr PIN:"), gbc);
        
        gbc.gridx = 1;
        JPasswordField pinField = new JPasswordField(6);
        panel.add(pinField, gbc);
        
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton confirmBtn = new JButton("✅ Confirm TeleBirr Payment");
        confirmBtn.setBackground(new Color(0, 128, 0));
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.addActionListener(e -> {
            String phone = phoneField.getText().trim();
            String pin = new String(pinField.getPassword());
            
            if (phone.isEmpty() || pin.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, 
                    "Please enter phone number and PIN!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!phone.matches("09\\d{8}")) {
                JOptionPane.showMessageDialog(dialog,
                    "Please enter a valid Ethiopian phone number (09XXXXXXXX)!",
                    "Invalid Phone",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String transactionId = "TEL" + generateTransactionId();
            currentPayment = new Payment();
            currentPayment.setPaymentMethod("TeleBirr");
            currentPayment.setAmount(totalAmount);
            currentPayment.setPhoneNumber(phone);
            currentPayment.setTransactionId(transactionId);
            currentPayment.setStatus("Pending");
            currentPayment.setPaymentDate(new Date());
            
            selectedPaymentMethod = "TeleBirr";
            
            JOptionPane.showMessageDialog(dialog,
                "✅ TeleBirr payment recorded!\n" +
                "Send ETB " + totalAmount + " to: 0918915545\n" +
                "Transaction ID: " + transactionId + "\n" +
                "Please process payment in the Payment tab.",
                "Payment Recorded",
                JOptionPane.INFORMATION_MESSAGE);
            
            dialog.dispose();
        });
        
        panel.add(confirmBtn, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showCbeBirrPaymentDialog() {
        JDialog dialog = new JDialog(this, "CBE Birr Payment", true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("🏦 CBE Birr Payment", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(25, 25, 112));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        gbc.gridwidth = 2;
        gbc.gridy = 1;
        JPanel payToPanel = new JPanel(new BorderLayout());
        payToPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(25, 25, 112), 1),
            "Send To This Number:"
        ));
        payToPanel.setBackground(new Color(240, 240, 255));
        
        JLabel payToLabel = new JLabel("📞 0918915545", JLabel.CENTER);
        payToLabel.setFont(new Font("Arial", Font.BOLD, 24));
        payToLabel.setForeground(new Color(25, 25, 112));
        payToPanel.add(payToLabel, BorderLayout.CENTER);
        panel.add(payToPanel, gbc);
        
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Your Phone Number:"), gbc);
        
        gbc.gridx = 1;
        JTextField phoneField = new JTextField(15);
        phoneField.setText("0918915545");
        panel.add(phoneField, gbc);
        
        gbc.gridy = 3;
        gbc.gridx = 0;
        panel.add(new JLabel("Amount (ETB):"), gbc);
        
        gbc.gridx = 1;
        JTextField amountField = new JTextField(String.format("%.2f", totalAmount));
        amountField.setEditable(false);
        amountField.setBackground(Color.LIGHT_GRAY);
        panel.add(amountField, gbc);
        
        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("CBE Birr PIN:"), gbc);
        
        gbc.gridx = 1;
        JPasswordField pinField = new JPasswordField(6);
        panel.add(pinField, gbc);
        
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton confirmBtn = new JButton("✅ Confirm CBE Birr Payment");
        confirmBtn.setBackground(new Color(25, 25, 112));
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.addActionListener(e -> {
            String phone = phoneField.getText().trim();
            String pin = new String(pinField.getPassword());
            
            if (phone.isEmpty() || pin.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, 
                    "Please enter phone number and PIN!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!phone.matches("09\\d{8}")) {
                JOptionPane.showMessageDialog(dialog,
                    "Please enter a valid Ethiopian phone number (09XXXXXXXX)!",
                    "Invalid Phone",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String transactionId = "CBE" + generateTransactionId();
            currentPayment = new Payment();
            currentPayment.setPaymentMethod("CBE Birr");
            currentPayment.setAmount(totalAmount);
            currentPayment.setPhoneNumber(phone);
            currentPayment.setTransactionId(transactionId);
            currentPayment.setStatus("Pending");
            currentPayment.setPaymentDate(new Date());
            
            selectedPaymentMethod = "CBE Birr";
            
            JOptionPane.showMessageDialog(dialog,
                "✅ CBE Birr payment recorded!\n" +
                "Send ETB " + totalAmount + " to: 0918915545\n" +
                "Transaction ID: " + transactionId + "\n" +
                "Please process payment in the Payment tab.",
                "Payment Recorded",
                JOptionPane.INFORMATION_MESSAGE);
            
            dialog.dispose();
        });
        
        panel.add(confirmBtn, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showBankTransferDialog() {
        JDialog dialog = new JDialog(this, "Bank Transfer Payment", true);
        dialog.setSize(600, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("💼 Bank Transfer Payment", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(139, 0, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        gbc.gridwidth = 2;
        gbc.gridy = 1;
        JPanel bankDetailsPanel = new JPanel(new BorderLayout());
        bankDetailsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 0, 0), 1),
            "Transfer To This Account:"
        ));
        bankDetailsPanel.setBackground(new Color(255, 250, 240));
        
        String bankDetails = 
            "🏦 Bank: Commercial Bank of Ethiopia\n" +
            "💰 Account No: 100012345678\n" +
            "👤 Account Name: Getasew Dejenie\n" +
            "💵 Amount: ETB " + String.format("%.2f", totalAmount);
        
        JTextArea detailsArea = new JTextArea(bankDetails);
        detailsArea.setEditable(false);
        detailsArea.setBackground(new Color(255, 250, 240));
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        bankDetailsPanel.add(detailsArea, BorderLayout.CENTER);
        panel.add(bankDetailsPanel, gbc);
        
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Your Account No:"), gbc);
        
        gbc.gridx = 1;
        JTextField accountField = new JTextField(20);
        accountField.setText("1000123456678");
        panel.add(accountField, gbc);
        
        gbc.gridy = 3;
        gbc.gridx = 0;
        panel.add(new JLabel("Your Name:"), gbc);
        
        gbc.gridx = 1;
        JTextField nameField = new JTextField(20);
        nameField.setText(currentCustomer.getFullName());
        panel.add(nameField, gbc);
        
        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("Upload Receipt:"), gbc);
        
        gbc.gridx = 1;
        JPanel receiptPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        receiptPanel.setBackground(Color.WHITE);
        
        JButton uploadBtn = new JButton("Choose File");
        JLabel receiptLabel = new JLabel("No file chosen");
        receiptLabel.setForeground(Color.GRAY);
        
        uploadBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "pdf"));
            
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                receiptPhotoFile = chooser.getSelectedFile();
                receiptLabel.setText(receiptPhotoFile.getName());
            }
        });
        
        receiptPanel.add(uploadBtn);
        receiptPanel.add(receiptLabel);
        panel.add(receiptPanel, gbc);
        
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton confirmBtn = new JButton("✅ I Have Transferred");
        confirmBtn.setBackground(new Color(139, 0, 0));
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setFont(new Font("Arial", Font.BOLD, 14));
        
        confirmBtn.addActionListener(e -> {
            if (receiptPhotoFile == null) {
                JOptionPane.showMessageDialog(dialog,
                    "Please upload receipt screenshot!",
                    "Receipt Required",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String transactionId = "BNK" + generateTransactionId();
            currentPayment = new Payment(); // FIXED: Use Payment class, not ReceiptFilePath
            currentPayment.setPaymentMethod("Bank Transfer");
            currentPayment.setAmount(totalAmount);
            currentPayment.setSenderName(nameField.getText());
            currentPayment.setAccountNumber(accountField.getText()); // Set account number
            currentPayment.setTransactionId(transactionId);
            currentPayment.setStatus("Pending");
            currentPayment.setPaymentDate(new Date());
            
            selectedPaymentMethod = "Bank Transfer";
            
            JOptionPane.showMessageDialog(dialog,
                "✅ Payment recorded!\n" +
                "Transaction ID: " + transactionId + "\n" +
                "Please process payment in the Payment tab.",
                "Bank Transfer Recorded",
                JOptionPane.INFORMATION_MESSAGE);
            
            dialog.dispose();
        });
        
        panel.add(confirmBtn, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void processPayment() {
        System.out.println("=== DEBUG: Starting processPayment() ===");
        
        if (currentPayment == null) {
            JOptionPane.showMessageDialog(null,
                "❌ No payment method selected!\n" +
                "Please select a payment method (TeleBirr, CBE Birr, or Bank Transfer) first.",
                "Payment Method Required",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        System.out.println("Payment Method: " + currentPayment.getPaymentMethod());
        System.out.println("Transaction ID: " + currentPayment.getTransactionId());
        System.out.println("Amount: " + currentPayment.getAmount());
        
        if (currentPayment.getPaymentMethod() == null || currentPayment.getPaymentMethod().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "❌ Payment method not specified!\n" +
                "Please select a valid payment method.",
                "Invalid Payment",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (currentPayment.getTransactionId() == null || currentPayment.getTransactionId().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "❌ Transaction ID missing!\n" +
                "Payment cannot be processed.",
                "Invalid Payment",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (currentOrderItems == null || currentOrderItems.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "No items in order to process payment!\n" +
                "Please add items to your order first.",
                "Empty Order",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (currentPayment.getPaymentMethod().equals("Bank Transfer")) {
            if (receiptPhotoFile == null || !receiptPhotoFile.exists()) {
                JOptionPane.showMessageDialog(null,
                    "Please upload receipt for bank transfer!\n" +
                    "A screenshot of the transfer confirmation is required.",
                    "Receipt Required",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        int confirm = JOptionPane.showConfirmDialog(null,
            "Confirm payment of ETB " + String.format("%.2f", totalAmount) + 
            " via " + currentPayment.getPaymentMethod() + "?\n\n" +
            "Transaction ID: " + currentPayment.getTransactionId(),
            "Confirm Payment",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        try {
            System.out.println("=== Creating order... ===");
            
            OrderDAO orderDAO = new OrderDAO();
            
            byte[] receiptData = null;
            String receiptFileName = "";
            String receiptHash = "";
            
            if (receiptPhotoFile != null && receiptPhotoFile.exists()) {
                try (FileInputStream fis = new FileInputStream(receiptPhotoFile)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        bos.write(buffer, 0, bytesRead);
                    }
                    receiptData = bos.toByteArray();
                    receiptFileName = receiptPhotoFile.getName();
                    receiptHash = ReceiptValidator.calculateFileHash(receiptPhotoFile);
                    System.out.println("Receipt file processed: " + receiptFileName);
                } catch (IOException e) {
                    System.err.println("Error reading receipt file: " + e.getMessage());
                }
            }
            
            Integer customerId = currentCustomer.getCustomerId() > 0 ? currentCustomer.getCustomerId() : null;
            
            System.out.println("Calling orderDAO.createOrder()...");
            int orderId = orderDAO.createOrder(
                customerId,
                currentCustomer.getFullName(),
                currentCustomer.getPhoneNumber(),
                "",
                "",
                receiptData,
                receiptFileName,
                receiptHash,
                totalAmount,
                currentOrderItems,
                totalAmount,
                false
            );
            
            System.out.println("Order created with ID: " + orderId);
            
            if (orderId <= 0) {
                JOptionPane.showMessageDialog(null,
                    "there is duplicate receipt!\n" +
                    "Please upload valid receipt!",
                    "payment process not succeed!",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            currentPayment.setOrderId(orderId);
            currentPayment.setStatus("Completed");
            currentPayment.setPaymentDate(new Date());
            
            System.out.println("=== Saving payment to database ===");
            System.out.println("Order ID: " + currentPayment.getOrderId());
            System.out.println("Payment Method: " + currentPayment.getPaymentMethod());
            System.out.println("Amount: " + currentPayment.getAmount());
            System.out.println("Transaction ID: " + currentPayment.getTransactionId());
            
            PaymentDAO paymentDAO = new PaymentDAO();
            boolean paymentSaved = paymentDAO.savePayment(currentPayment);
            
            if (paymentSaved) {
                System.out.println("✅ Payment saved successfully!");
                
                String receipt = generateReceipt(currentPayment.getTransactionId());
                
                JTextArea receiptArea = new JTextArea(receipt);
                receiptArea.setEditable(false);
                receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                
                JOptionPane.showMessageDialog(null,
                    new JScrollPane(receiptArea),
                    "✅ Order & Payment Successful!",
                    JOptionPane.INFORMATION_MESSAGE);
                
                double currentSpent = currentCustomer.getTotalSpent();
                currentCustomer.setTotalSpent(currentSpent + totalAmount);
                currentCustomer.setTotalOrders(currentCustomer.getTotalOrders() + 1);
                
                currentOrderItems.clear();
                selectedPaymentMethod = "";
                receiptPhotoFile = null;
                updateOrderSummary();
                
                JTabbedPane parent = (JTabbedPane) getContentPane().getComponent(0);
                parent.setSelectedIndex(0);
                
                JOptionPane.showMessageDialog(null,
                    "Thank you for your payment!\n" +
                    "Your order has been processed successfully.\n" +
                    "You can view your order history in the Home tab.",
                    "Payment Complete",
                    JOptionPane.INFORMATION_MESSAGE);
                
            } else {
                System.err.println("❌ Failed to save payment!");
                JOptionPane.showMessageDialog(null,
                    "Failed to save payment record!\n" +
                    "Order #" + orderId + " was created successfully.\n" +
                    "Please contact support with Transaction ID: " + currentPayment.getTransactionId(),
                    "Payment Error",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error in processPayment(): " + e.getMessage());
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null,
                "Payment processing error:\n" + e.getMessage() + 
                "\n\nPlease try again or contact support.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateCustomerTotalSpent(int orderId) {
        try {
            double currentSpent = currentCustomer.getTotalSpent();
            currentCustomer.setTotalSpent(currentSpent + totalAmount);
            currentCustomer.setTotalOrders(currentCustomer.getTotalOrders() + 1);
        } catch (Exception e) {
            System.err.println("Error updating customer total: " + e.getMessage());
        }
    }
    
    private void loadTransactionHistory(DefaultTableModel model) {
        try {
            PaymentDAO paymentDAO = new PaymentDAO();
            List<Payment> payments = paymentDAO.getCustomerPayments(currentCustomer.getCustomerId());
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            
            for (Payment payment : payments) {
                Object[] row = {
                    dateFormat.format(payment.getPaymentDate()),
                    payment.getPaymentMethod(),
                    String.format("ETB %.2f", payment.getAmount()),
                    payment.getStatus(),
                    payment.getTransactionId()
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("Error loading transaction history: " + e.getMessage());
        }
    }
    
    private String generateReceipt(String transactionId) {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        sb.append("========================================\n");
        sb.append("         ETHIOPIAN RESTAURANT           \n");
        sb.append("            PAYMENT RECEIPT             \n");
        sb.append("========================================\n");
        sb.append("Receipt No:    ").append(transactionId).append("\n");
        sb.append("Date:          ").append(dateFormat.format(new Date())).append("\n");
        sb.append("Customer:      ").append(currentCustomer.getFullName()).append("\n");
        sb.append("Phone:         ").append(currentCustomer.getPhoneNumber()).append("\n");
        sb.append("----------------------------------------\n");
        sb.append("Payment Method: ").append(currentPayment.getPaymentMethod()).append("\n");
        
        if (currentPayment.getPaymentMethod().equals("TeleBirr") || 
            currentPayment.getPaymentMethod().equals("CBE Birr")) {
            sb.append("Phone:         ").append(currentPayment.getPhoneNumber()).append("\n");
        } else if (currentPayment.getPaymentMethod().equals("Bank Transfer")) {
            sb.append("Sender:        ").append(currentPayment.getSenderName()).append("\n");
            sb.append("Account:       ").append(currentPayment.getAccountNumber()).append("\n");
        }
        
        sb.append("Transaction ID: ").append(currentPayment.getTransactionId()).append("\n");
        sb.append("Amount:         ETB ").append(String.format("%.2f", currentPayment.getAmount())).append("\n");
        sb.append("Status:         ").append(currentPayment.getStatus()).append("\n");
        sb.append("========================================\n");
        sb.append("Order Items:\n");
        
        for (OrderItem item : currentOrderItems) {
            sb.append(String.format("- %s x%d = ETB %.2f\n",
                item.getMenuItem().getItemName(),
                item.getQuantity(),
                item.getMenuItem().getPrice() * item.getQuantity()));
        }
        
        sb.append("========================================\n");
        sb.append("Thank you for your payment!\n");
        sb.append("Visit us again soon!\n");
        sb.append("========================================\n");
        
        return sb.toString();
    }
    
    private String generateTransactionId() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
    
    private void loadAllMenuItems() {
        try {
            MenuDAO menuDAO = new MenuDAO();
            allMenuItems = menuDAO.getAllMenuItems();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading menu items: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void loadAllMenuItemsToTable() {
        tableModel.setRowCount(0);
        
        if (allMenuItems.isEmpty()) {
            loadAllMenuItems();
        }
        
        for (MenuItem item : allMenuItems) {
            Object[] row = {
                item.getItemId(),
                item.getItemName(),
                String.format("ETB %.2f", item.getPrice()),
                getCategoryName(item.getCategoryId()),
                item.isAvailable() ? "Yes" : "No",
                item.getDescription(),
                "Add to Order"
            };
            tableModel.addRow(row);
        }
    }
    
    private void customizeSearchTable() {
        searchTable.setRowHeight(35);
        searchTable.getTableHeader().setBackground(new Color(70, 130, 180));
        searchTable.getTableHeader().setForeground(Color.WHITE);
        searchTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        searchTable.setFont(new Font("Arial", Font.PLAIN, 12));
        searchTable.setGridColor(Color.LIGHT_GRAY);
        
        searchTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        searchTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        searchTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        searchTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        searchTable.getColumnModel().getColumn(4).setPreferredWidth(70);
        searchTable.getColumnModel().getColumn(5).setPreferredWidth(200);
        searchTable.getColumnModel().getColumn(6).setPreferredWidth(80);
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        searchTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        searchTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        searchTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        searchTable.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
        
        searchTable.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer("Add"));
        searchTable.getColumnModel().getColumn(6).setCellEditor(new ButtonEditor(new JCheckBox(), this));
    }
    
    private void performSearch(JTextField minPriceField, JTextField maxPriceField) {
        String searchText = searchField.getText().trim();
        String filterType = (String) filterCombo.getSelectedItem();
        
        tableModel.setRowCount(0);
        
        if (allMenuItems.isEmpty()) {
            loadAllMenuItems();
        }
        
        for (MenuItem item : allMenuItems) {
            boolean matches = false;
            
            String itemName = item.getItemName();
            String description = item.getDescription() != null ? item.getDescription() : "";
            String category = getCategoryName(item.getCategoryId());
            double price = item.getPrice();
            
            if (searchText.isEmpty()) {
                matches = true;
            } else {
                String searchLower = searchText.toLowerCase();
                String itemNameLower = itemName.toLowerCase();
                String descLower = description.toLowerCase();
                String categoryLower = category.toLowerCase();
                String priceStr = String.format("%.2f", price);
                
                switch(filterType) {
                    case "All Items":
                        matches = itemNameLower.contains(searchLower) || 
                                 descLower.contains(searchLower) ||
                                 categoryLower.contains(searchLower) ||
                                 priceStr.contains(searchText);
                        break;
                    case "Name":
                        matches = itemNameLower.contains(searchLower);
                        break;
                    case "Category":
                        matches = categoryLower.contains(searchLower);
                        break;
                    case "Price Range":
                        try {
                            double minPrice = Double.parseDouble(minPriceField.getText());
                            double maxPrice = Double.parseDouble(maxPriceField.getText());
                            matches = price >= minPrice && price <= maxPrice;
                        } catch (NumberFormatException e) {
                            matches = false;
                        }
                        break;
                    case "Available Only":
                        matches = item.isAvailable() && 
                                 (itemNameLower.contains(searchLower) || searchText.isEmpty());
                        break;
                    case "Vegetarian":
                        matches = (categoryLower.contains("vegetable") || 
                                  categoryLower.contains("salad") ||
                                  descLower.contains("vegetarian")) &&
                                  (itemNameLower.contains(searchLower) || searchText.isEmpty());
                        break;
                    case "Non-Vegetarian":
                        matches = (!categoryLower.contains("vegetable") && 
                                  !categoryLower.contains("salad") &&
                                  !descLower.contains("vegetarian")) &&
                                  (itemNameLower.contains(searchLower) || searchText.isEmpty());
                        break;
                }
            }
            
            if (matches) {
                Object[] row = {
                    item.getItemId(),
                    item.getItemName(),
                    String.format("ETB %.2f", item.getPrice()),
                    getCategoryName(item.getCategoryId()),
                    item.isAvailable() ? "Yes" : "No",
                    item.getDescription(),
                    "Add to Order"
                };
                tableModel.addRow(row);
            }
        }
        
        if (!searchText.isEmpty()) {
            highlightSearchResults(searchText);
        }
        
        if (tableModel.getRowCount() == 0 && !searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No items found matching: " + searchText,
                "No Results",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void highlightSearchResults(String searchText) {
        final String searchLower = searchText.toLowerCase();
        
        searchTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, 
                        isSelected, hasFocus, row, column);
                
                if (value != null && column != 6 && 
                    value.toString().toLowerCase().contains(searchLower)) {
                    c.setBackground(new Color(255, 255, 200));
                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                } else if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                    c.setFont(c.getFont().deriveFont(Font.PLAIN));
                }
                
                if (column == 4) {
                    if ("Yes".equals(value)) {
                        c.setForeground(new Color(0, 128, 0));
                    } else {
                        c.setForeground(Color.RED);
                    }
                }
                
                return c;
            }
        });
        searchTable.repaint();
    }
    
    private String getCategoryName(int categoryId) {
        switch(categoryId) {
            case 1: return "Breakfast";
            case 2: return "Lunch";
            case 3: return "Dinner";
            case 4: return "Alcoholic Drinks";
            case 5: return "Mocktails & Soft Drinks";
            case 6: return "Fresh Juice";
            case 7: return "Hot Drinks";
            case 8: return "Sweet Food";
            case 9: return "Vegetables";
            default: return "Other";
        }
    }
    
    private void cancelPayment() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to cancel the payment?",
            "Confirm Cancel",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            currentPayment = null;
            selectedPaymentMethod = "";
            JOptionPane.showMessageDialog(this,
                "Payment cancelled.",
                "Payment Cancelled",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String text) {
            setText(text);
            setOpaque(true);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            setBackground(new Color(70, 130, 180));
            setForeground(Color.WHITE);
            setFont(new Font("Arial", Font.BOLD, 11));
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        private RestaurantManagementSystem parentFrame;
        
        public ButtonEditor(JCheckBox checkBox, RestaurantManagementSystem parent) {
            super(checkBox);
            this.parentFrame = parent;
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            button.setBackground(new Color(50, 205, 50));
            button.setForeground(Color.WHITE);
            isPushed = true;
            return button;
        }
        
        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                int row = searchTable.getSelectedRow();
                if (row >= 0) {
                    int itemId = (int) tableModel.getValueAt(row, 0);
                    String itemName = (String) tableModel.getValueAt(row, 1);
                    
                    for (MenuItem item : allMenuItems) {
                        if (item.getItemId() == itemId) {
                            addItemToOrder(item);
                            
                            JOptionPane.showMessageDialog(parentFrame,
                                "✅ Added to order!\n\n" +
                                "Item: " + itemName + "\n" +
                                "Price: ETB " + item.getPrice() + "\n\n" +
                                "Go to 🛒 Order tab to view your cart.",
                                "Item Added",
                                JOptionPane.INFORMATION_MESSAGE);
                            break;
                        }
                    }
                }
            }
            isPushed = false;
            return label;
        }
        
        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
    
    private void showCategoryItems(String category, int categoryId) {
        JDialog dialog = new JDialog(this, category + " Menu", true);
        dialog.setSize(600, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel(category + " Menu", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        JButton closeBtn = new JButton("Close");
        closeBtn.setBackground(Color.WHITE);
        closeBtn.setForeground(new Color(70, 130, 180));
        closeBtn.addActionListener(e -> dialog.dispose());
        headerPanel.add(closeBtn, BorderLayout.EAST);
        
        JPanel itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        itemsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        itemsPanel.setBackground(Color.WHITE);
        
        CategoryDAO categoryDAO = new CategoryDAO();
        
        try {
            List<MenuItem> items = categoryDAO.getMenuItemsByCategory(categoryId);
            
            if (items == null || items.isEmpty()) {
                JLabel noItemsLabel = new JLabel("No items available in this category", JLabel.CENTER);
                noItemsLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                noItemsLabel.setForeground(Color.GRAY);
                itemsPanel.add(noItemsLabel);
            } else {
                for (MenuItem item : items) {
                    JPanel itemPanel = createMenuItemPanel(item);
                    itemsPanel.add(itemPanel);
                    itemsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                }
            }
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading items: " + e.getMessage(), JLabel.CENTER);
            errorLabel.setFont(new Font("Arial", Font.BOLD, 12));
            errorLabel.setForeground(Color.RED);
            itemsPanel.add(errorLabel);
            e.printStackTrace();
        }
        
        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        scrollPane.setBorder(null);
        
        dialog.add(headerPanel, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);
        
        dialog.setVisible(true);
    }
    
    private JPanel createMenuItemPanel(MenuItem item) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        panel.setBackground(Color.WHITE);
        panel.setMaximumSize(new Dimension(550, 80));
        
        JPanel infoPanel = new JPanel(new GridLayout(2, 1));
        infoPanel.setBackground(Color.WHITE);
        
        JLabel nameLabel = new JLabel(item.getItemName());
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        nameLabel.setForeground(new Color(70, 130, 180));
        
        JLabel descLabel = new JLabel(item.getDescription());
        descLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        descLabel.setForeground(Color.GRAY);
        
        infoPanel.add(nameLabel);
        infoPanel.add(descLabel);
        
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.setBackground(Color.WHITE);
        
        JLabel priceLabel = new JLabel(String.format("ETB %.2f", item.getPrice()));
        priceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        priceLabel.setForeground(new Color(34, 139, 34));
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.WHITE);
        
        JButton addBtn = new JButton("Add to Order");
        addBtn.setBackground(new Color(50, 205, 50));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        addBtn.addActionListener(e -> {
            addItemToOrder(item);
            JOptionPane.showMessageDialog(this, 
                "Added: " + item.getItemName() + "\nPrice: ETB " + item.getPrice(),
                "Item Added", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        JButton removeBtn = new JButton("Remove");
        removeBtn.setBackground(new Color(220, 20, 60));
        removeBtn.setForeground(Color.WHITE);
        removeBtn.setFocusPainted(false);
        removeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        removeBtn.addActionListener(e -> {
            removeItemFromOrder(item);
            JOptionPane.showMessageDialog(this, 
                "Removed: " + item.getItemName(),
                "Item Removed", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(removeBtn);
        
        controlPanel.add(priceLabel, BorderLayout.WEST);
        controlPanel.add(buttonPanel, BorderLayout.EAST);
        
        panel.add(infoPanel, BorderLayout.CENTER);
        panel.add(controlPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createOrderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(240, 248, 255));
        
        orderSummaryArea = new JTextArea(15, 40);
        orderSummaryArea.setEditable(false);
        orderSummaryArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        orderSummaryArea.setText("Your order is empty.\nAdd items from the Menu tab.");
        
        JScrollPane summaryScroll = new JScrollPane(orderSummaryArea);
        summaryScroll.setBorder(BorderFactory.createTitledBorder("Order Summary"));
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        controlPanel.setBackground(new Color(240, 248, 255));
        
        if (totalAmountLabel == null) {
            totalAmountLabel = new JLabel("Total: ETB 0.00");
        }
        totalAmountLabel.setFont(new Font("Arial", Font.BOLD, 18));
        totalAmountLabel.setForeground(new Color(34, 139, 34));
        
        JButton clearBtn = createOrderButton("Clear Order", new Color(220, 20, 60));
        JButton submitBtn = createOrderButton("Proceed to Payment", new Color(50, 205, 50));
        JButton menuBtn = createOrderButton("Back to Menu", new Color(70, 130, 180));
        
        controlPanel.add(totalAmountLabel);
        controlPanel.add(clearBtn);
        controlPanel.add(submitBtn);
        controlPanel.add(menuBtn);
        
        clearBtn.addActionListener(e -> clearOrder());
        submitBtn.addActionListener(e -> {
            if (currentOrderItems.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Please add items to your order first!",
                    "Empty Order",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            JTabbedPane parent = (JTabbedPane) getContentPane().getComponent(0);
            parent.setSelectedIndex(4);
        });
        menuBtn.addActionListener(e -> {
            JTabbedPane parent = (JTabbedPane) getContentPane().getComponent(0);
            parent.setSelectedIndex(1);
        });
        
        JPanel formPanel = createOrderFormPanel();
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(summaryScroll, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createOrderFormPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Order Details"));
        panel.setBackground(Color.WHITE);
        
        JPanel customerPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        customerPanel.setBorder(BorderFactory.createTitledBorder("Customer Info"));
        customerPanel.setBackground(Color.WHITE);
        
        JTextField nameField = new JTextField(currentCustomer.getFullName());
        JTextField phoneField = new JTextField(currentCustomer.getPhoneNumber());
        
        customerPanel.add(new JLabel("Name:"));
        customerPanel.add(nameField);
        customerPanel.add(new JLabel("Phone:"));
        customerPanel.add(phoneField);
        
        JPanel deliveryPanel = new JPanel(new BorderLayout());
        deliveryPanel.setBorder(BorderFactory.createTitledBorder("Delivery Options"));
        deliveryPanel.setBackground(Color.WHITE);
        
        JCheckBox deliveryCheck = new JCheckBox("Delivery Required");
        JTextArea addressArea = new JTextArea(3, 30);
        addressArea.setEditable(false);
        addressArea.setBackground(Color.LIGHT_GRAY);
        
        deliveryCheck.addActionListener(e -> {
            boolean selected = deliveryCheck.isSelected();
            addressArea.setEditable(selected);
            addressArea.setBackground(selected ? Color.WHITE : Color.LIGHT_GRAY);
            if (!selected) {
                addressArea.setText("");
            }
        });
        
        deliveryPanel.add(deliveryCheck, BorderLayout.NORTH);
        deliveryPanel.add(new JScrollPane(addressArea), BorderLayout.CENTER);
        
        JTextArea instructionsArea = new JTextArea(3, 30);
        JScrollPane instructionsScroll = new JScrollPane(instructionsArea);
        instructionsScroll.setBorder(BorderFactory.createTitledBorder("Special Instructions"));
        
        JPanel receiptPanel = new JPanel(new FlowLayout());
        receiptPanel.setBackground(Color.WHITE);
        JButton uploadBtn = new JButton("Upload Receipt Photo");
        JLabel receiptStatus = new JLabel("No receipt uploaded");
        uploadBtn.setBackground(new Color(70, 130, 180));
        uploadBtn.setForeground(Color.WHITE);
        
        uploadBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));
            
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                receiptPhotoFile = chooser.getSelectedFile();
                receiptStatus.setText(receiptPhotoFile.getName() + " (" + receiptPhotoFile.length()/1024 + " KB)");
            }
        });
        
        receiptPanel.add(uploadBtn);
        receiptPanel.add(receiptStatus);
        
        panel.add(customerPanel);
        panel.add(deliveryPanel);
        panel.add(instructionsScroll);
        panel.add(receiptPanel);
        
        return panel;
    }
    
    private JButton createOrderButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private void addItemToOrder(MenuItem item) {
        for (OrderItem orderItem : currentOrderItems) {
            if (orderItem.getMenuItem().getItemId() == item.getItemId()) {
                orderItem.setQuantity(orderItem.getQuantity() + 1);
                updateOrderSummary();
                return;
            }
        }
        currentOrderItems.add(new OrderItem(item, 1));
        updateOrderSummary();
    }
    
    private void removeItemFromOrder(MenuItem item) {
        currentOrderItems.removeIf(orderItem -> 
            orderItem.getMenuItem().getItemId() == item.getItemId());
        updateOrderSummary();
    }
    
    private void clearOrder() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to clear the entire order?",
            "Confirm Clear",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            currentOrderItems.clear();
            updateOrderSummary();
            receiptPhotoFile = null;
            JOptionPane.showMessageDialog(this, "Order cleared successfully!", "Order Cleared", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void updateOrderSummary() {
        if (totalAmountLabel == null) {
            totalAmountLabel = new JLabel("Total: ETB 0.00");
        }
        
        StringBuilder sb = new StringBuilder();
        totalAmount = 0;
        
        if (currentOrderItems.isEmpty()) {
            sb.append("Your order is empty.\n");
            sb.append("Add items from the Menu tab.\n");
            sb.append("================================\n");
            orderSummaryArea.setText(sb.toString());
            totalAmountLabel.setText("Total: ETB 0.00");
            return;
        }
        
        sb.append(String.format("%-30s %-6s %-10s %-12s\n", "Item", "Qty", "Unit Price", "Subtotal"));
        sb.append("===============================================================\n");
        
        for (OrderItem item : currentOrderItems) {
            double subtotal = item.getMenuItem().getPrice() * item.getQuantity();
            totalAmount += subtotal;
            sb.append(String.format("%-30s %-6d ETB%-8.2f ETB%-10.2f\n",
                item.getMenuItem().getItemName(),
                item.getQuantity(),
                item.getMenuItem().getPrice(),
                subtotal));
        }
        
        sb.append("===============================================================\n");
        sb.append(String.format("%-30s %-6s %-10s ETB%-10.2f\n", 
            "TOTAL", "", "", totalAmount));
        
        orderSummaryArea.setText(sb.toString());
        totalAmountLabel.setText(String.format("Total: ETB %.2f", totalAmount));
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(null,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            
            JOptionPane.showMessageDialog(null,
                "✅ Logged out successfully!\n\n" +
                "User: " + currentCustomer.getFullName() + "\n" +
                "Thank you for using our restaurant system.\n\n" +
                "Please restart the application to login again.",
                "Logout Successful",
                JOptionPane.INFORMATION_MESSAGE);
            
            System.exit(0);
            
            System.out.println("User logged out: " + currentCustomer.getFullName());
        }
    }
    
    private void backToLogin() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Return to login screen? All unsaved data will be lost.",
            "Confirm",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            if (loginFrame != null) {
                loginFrame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null,
                    "Application closed. Please restart to login.",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        }
    }
}