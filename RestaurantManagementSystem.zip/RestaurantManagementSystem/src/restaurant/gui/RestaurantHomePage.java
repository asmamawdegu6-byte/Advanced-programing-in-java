package restaurant.gui;

import restaurant.dao.CustomerDAO;
import restaurant.models.Customer;
import restaurant.validation.InputValidator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class RestaurantHomePage extends JFrame {
    private JTextField loginPhoneField;
    private JPasswordField loginPasswordField;
    private JTextField registerNameField;
    private JTextField registerPhoneField;
    private JPasswordField registerPasswordField;
    private JTextField registerEmailField;
    private JTextField registerAddressField;
    private JButton loginBtn;
    private JButton registerBtn;
    private JButton guestBtn;
    private JButton adminBtn;
    private JFrame JFrame;
    
    public RestaurantHomePage() {
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Restaurant sytem Home page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 650);
        setLocationRelativeTo(null);
        setResizable(false);
        
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        
        // Login Tab
        JPanel loginPanel = createLoginPanel();
        tabbedPane.addTab("Login", loginPanel);
        
        // Register Tab
        JPanel registerPanel = createRegisterPanel();
        tabbedPane.addTab("Register", registerPanel);
        
        add(tabbedPane);
    }
    
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel headerLabel = new JLabel("Customer Login", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(new Color(70, 130, 180));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        
        // Phone Number
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Phone Number:"), gbc);
        
        gbc.gridx = 1;
        loginPhoneField = new JTextField(15);
        loginPhoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        // Add Enter key listener for quick login
        loginPhoneField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    loginPasswordField.requestFocus();
                }
            }
        });
        formPanel.add(loginPhoneField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        loginPasswordField = new JPasswordField(15);
        loginPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        // Add Enter key listener for quick login
        loginPasswordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    handleLogin();
                }
            }
        });
        formPanel.add(loginPasswordField, gbc);
        
        // Login Button
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        loginBtn = createStyledButton("Login", new Color(70, 130, 180));
        formPanel.add(loginBtn, gbc);
        
        // Guest Button
        gbc.gridy = 3;
        guestBtn = createStyledButton("Continue as Guest", new Color(100, 149, 237));
        formPanel.add(guestBtn, gbc);
        
        // Admin Button
        gbc.gridy = 4;
        adminBtn = createStyledButton("Admin Login", new Color(169, 169, 169));
        formPanel.add(adminBtn, gbc);
        
        // Button actions
        loginBtn.addActionListener(e -> handleLogin());
        guestBtn.addActionListener(e -> handleGuestLogin());
        adminBtn.addActionListener(e -> {
            new AdminLogin().setVisible(true);
            dispose();
        });
        
        // Forgot password label
        gbc.gridy = 5;
        JLabel forgotLabel = new JLabel("<html><center><br>Contact gech@gmail.com</center></html>", JLabel.CENTER);
        forgotLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        forgotLabel.setForeground(Color.blue);
        formPanel.add(forgotLabel, gbc);
        
        panel.add(headerLabel, BorderLayout.NORTH);
        panel.add(formPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header
        JLabel headerLabel = new JLabel("Customer Registration", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(new Color(70, 130, 180));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        // Form panel with scroll
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.blue);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        
        int row = 0;
        
        // Full Name
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Full Name:"), gbc);
        
        gbc.gridx = 1;
        registerNameField = new JTextField(20);
        registerNameField.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(registerNameField, gbc);
        
        // Phone Number
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Phone Number:"), gbc);
        
        gbc.gridx = 1;
        registerPhoneField = new JTextField(20);
        registerPhoneField.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(registerPhoneField, gbc);
        
        // Password
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        registerPasswordField = new JPasswordField(20);
        registerPasswordField.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(registerPasswordField, gbc);
        
        // Email
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Email:"), gbc);
        
        gbc.gridx = 1;
        registerEmailField = new JTextField(20);
        registerEmailField.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(registerEmailField, gbc);
        
        // Address
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Address:"), gbc);
        
        gbc.gridx = 1;
        registerAddressField = new JTextField(20);
        registerAddressField.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(registerAddressField, gbc);
        
        // Register Button
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        registerBtn = createStyledButton("Register", new Color(30, 144, 255));
        formPanel.add(registerBtn, gbc);
        
        // Button action
        registerBtn.addActionListener(e -> handleRegistration());
        
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        
        panel.add(headerLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.red);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private void handleLogin() {
        String phone = loginPhoneField.getText().trim();
        String password = new String(loginPasswordField.getPassword());
        
        // Debug log
        System.out.println("Login attempt - Phone: " + phone + ", Password length: " + password.length());
        
        // Validate phone number
        InputValidator.ValidationResult phoneValidation = InputValidator.validatePhoneNumber(phone);
        if (!phoneValidation.isValid()) {
            showErrorDialog(phoneValidation.getMessage());
            loginPhoneField.requestFocus();
            return;
        }
        
        // Validate password
        if (password.isEmpty()) {
            showErrorDialog("Password is required!");
            loginPasswordField.requestFocus();
            return;
        }
        
        if (password.length() < 4) {
            showErrorDialog("Password must be at least 4 characters!");
            loginPasswordField.requestFocus();
            return;
        }
        
        // Show loading indicator
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        loginBtn.setEnabled(false);
        
        // Try login
        try {
            CustomerDAO customerDAO = new CustomerDAO();
            Customer customer = customerDAO.loginCustomer(phone, password);
            
            if (customer != null) {
                System.out.println("Login successful for: " + customer.getFullName());
                
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(this, 
                        "Welcome back, " + customer.getFullName() + "!", 
                        "Login Successful", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    new RestaurantManagementSystem(customer).setVisible(true);
                    dispose();
                });
            } else {
                showErrorDialog("Invalid phone number or password!\nPlease check and try again.");
                loginPasswordField.setText("");
                loginPasswordField.requestFocus();
            }
        } catch (Exception e) {
            showErrorDialog("Login error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            setCursor(Cursor.getDefaultCursor());
            loginBtn.setEnabled(true);
        }
    }
    
    private void handleGuestLogin() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Continue as guest? You will need to provide personal details when ordering.",
            "Guest Login",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
            
        if (confirm == JOptionPane.YES_OPTION) {
            Customer guest = new Customer();
            guest.setFullName("Guest Customer");
            guest.setCustomerType("GUEST");
            guest.setPhoneNumber("0000000000");
            
            SwingUtilities.invokeLater(() -> {
                new RestaurantManagementSystem(guest).setVisible(true);
                dispose();
            });
        }
    }
    
    private void handleRegistration() {
        String name = registerNameField.getText().trim();
        String phone = registerPhoneField.getText().trim();
        String password = new String(registerPasswordField.getPassword());
        String email = registerEmailField.getText().trim();
        String address = registerAddressField.getText().trim();
        
        // Debug log
        System.out.println("Registration attempt - Name: " + name + ", Phone: " + phone);
        
        // Validate all fields
        InputValidator.ValidationResult nameValidation = InputValidator.validateName(name);
        if (!nameValidation.isValid()) {
            showErrorDialog(nameValidation.getMessage());
            registerNameField.requestFocus();
            return;
        }
        
        InputValidator.ValidationResult phoneValidation = InputValidator.validatePhoneNumber(phone);
        if (!phoneValidation.isValid()) {
            showErrorDialog(phoneValidation.getMessage());
            registerPhoneField.requestFocus();
            return;
        }
        
        if (password.isEmpty()) {
            showErrorDialog("Password is required!");
            registerPasswordField.requestFocus();
            return;
        }
        
        if (password.length() < 4) {
            showErrorDialog("Password must be at least 4 characters!");
            registerPasswordField.requestFocus();
            return;
        }
        
        if (email.isEmpty()) {
            showErrorDialog("Email is required!");
            registerEmailField.requestFocus();
            return;
        }
        
        if (!email.contains("@") || !email.contains(".")) {
            showErrorDialog("Please enter a valid email address!");
            registerEmailField.requestFocus();
            return;
        }
        
        if (address.isEmpty()) {
            showErrorDialog("Address is required!");
            registerAddressField.requestFocus();
            return;
        }
        
        if (address.length() < 5) {
            showErrorDialog("Please enter a complete address!");
            registerAddressField.requestFocus();
            return;
        }
        
        // Show loading indicator
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        registerBtn.setEnabled(false);
        
        try {
            Customer customer = new Customer();
            customer.setFullName(name);
            customer.setPhoneNumber(phone);
            customer.setPassword(password);
            customer.setEmail(email);
            customer.setAddress(address);
            customer.setCustomerType("REGISTERED");
            
            CustomerDAO customerDAO = new CustomerDAO();
            boolean success = customerDAO.registerCustomer(customer);
            
            if (success) {
                System.out.println("Registration successful for: " + customer.getFullName());
                
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(this,
                        "✅ Registration successful!\n\n" +
                        "Customer ID: " + customer.getCustomerId() + "\n" +
                        "Name: " + customer.getFullName() + "\n" +
                        "Phone: " + customer.getPhoneNumber() + "\n\n" +
                        "You will be automatically logged in.",
                        "Registration Complete",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Auto-login after registration
                    new RestaurantManagementSystem(customer).setVisible(true);
                    dispose();
                });
            } else {
                showErrorDialog("Registration failed!\nPhone number or email may already exist.");
            }
        } catch (Exception e) {
            showErrorDialog("Registration error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            setCursor(Cursor.getDefaultCursor());
            registerBtn.setEnabled(true);
        }
    }
    
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, 
            message, 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    public static void main(String[] args) {
        // Set Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Test database connection
        System.out.println("Testing database connection...");
        CustomerDAO dao = new CustomerDAO();
        boolean connected = dao.testConnection();
        System.out.println("Database connection: " + (connected ? "✅ SUCCESS" : "❌ FAILED"));
        
        // Launch GUI
        SwingUtilities.invokeLater(() -> {
            RestaurantHomePage homePage = new RestaurantHomePage();
            homePage.setVisible(true);
        });
    }
}