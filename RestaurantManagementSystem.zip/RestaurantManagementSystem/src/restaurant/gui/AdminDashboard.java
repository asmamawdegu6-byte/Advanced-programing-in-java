package restaurant.gui;

import restaurant.dao.AdminDAO;
import restaurant.dao.CategoryDAO;
import restaurant.models.Admin;
import restaurant.models.MenuItem;
import restaurant.models.Customer;
import restaurant.models.Order;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminDashboard extends JFrame {
    private final Admin currentAdmin;
    private final AdminDAO adminDAO;
    
    public AdminDashboard(Admin admin) {
        this.currentAdmin = admin;
        this.adminDAO = new AdminDAO();
        initializeDashboard();
    }
    
    private void initializeDashboard() {
        setTitle("Admin Dashboard - Group 5 Restaurant");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Add tabs
        tabbedPane.addTab("Dashboard", createDashboardPanel());
        tabbedPane.addTab("Menu Management", createMenuManagementPanel());
        tabbedPane.addTab("Order Management", createOrderManagementPanel());
        tabbedPane.addTab("Customer Management", createCustomerManagementPanel());
        tabbedPane.addTab("Reports", createReportsPanel());
        
        add(tabbedPane);
    }
    
    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Welcome message
        JLabel welcomeLabel = new JLabel("Welcome, " + currentAdmin.getFullName() + "!", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.BLUE);
        
        // Statistics
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Quick Statistics"));
        
        double totalRevenue = adminDAO.getTotalRevenue();
        int totalOrders = adminDAO.getTotalOrders();
        
        JLabel revenueLabel = new JLabel(String.format("Total Revenue: $%.2f", totalRevenue), JLabel.CENTER);
        JLabel ordersLabel = new JLabel("Total Orders: " + totalOrders, JLabel.CENTER);
        JLabel adminLabel = new JLabel("Admin Role: " + currentAdmin.getRole(), JLabel.CENTER);
        JLabel timeLabel = new JLabel("Login Time: " + new java.util.Date(), JLabel.CENTER);
        
        revenueLabel.setFont(new Font("Arial", Font.BOLD, 16));
        ordersLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        statsPanel.add(revenueLabel);
        statsPanel.add(ordersLabel);
        statsPanel.add(adminLabel);
        statsPanel.add(timeLabel);
        
        panel.add(welcomeLabel, BorderLayout.NORTH);
        panel.add(statsPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createMenuManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Controls
        JPanel controlPanel = new JPanel(new FlowLayout());
        JButton addBtn = new JButton("Add Item");
        JButton editBtn = new JButton("Edit Item");
        JButton deleteBtn = new JButton("Delete Item");
        JButton refreshBtn = new JButton("Refresh");
        
        controlPanel.add(addBtn);
        controlPanel.add(editBtn);
        controlPanel.add(deleteBtn);
        controlPanel.add(refreshBtn);
        
        // Menu items table
        String[] columns = {"ID", "Name", "Description", "Price", "Category", "Available"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable menuTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(menuTable);
        
        // Load menu items
        loadMenuItems(model);
        
        // Button actions
        addBtn.addActionListener(e -> showAddMenuItemDialog());
        refreshBtn.addActionListener(e -> loadMenuItems(model));
        deleteBtn.addActionListener(e -> {
            int selectedRow = menuTable.getSelectedRow();
            if (selectedRow >= 0) {
                int itemId = (int) model.getValueAt(selectedRow, 0);
                deleteMenuItem(itemId, model);
            } else {
                JOptionPane.showMessageDialog(this, "Please select an item to delete!");
            }
        });
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createOrderManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Controls
        JPanel controlPanel = new JPanel(new FlowLayout());
        JButton refreshBtn = new JButton("Refresh Orders");
        JButton approveBtn = new JButton("Approve Order");
        JButton rejectBtn = new JButton("Reject Order");
        
        controlPanel.add(refreshBtn);
        controlPanel.add(approveBtn);
        controlPanel.add(rejectBtn);
        
        // Orders table
        String[] columns = {"Order ID", "Customer", "Phone", "Amount", "Status", "Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable ordersTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(ordersTable);
        
        // Load orders
        loadOrders(model);
        
        // Button actions
        refreshBtn.addActionListener(e -> loadOrders(model));
        approveBtn.addActionListener(e -> {
            int selectedRow = ordersTable.getSelectedRow();
            if (selectedRow >= 0) {
                int orderId = (int) model.getValueAt(selectedRow, 0);
                boolean success = adminDAO.updateOrderStatus(orderId, "APPROVED", "");
                if (success) {
                    JOptionPane.showMessageDialog(this, "Order approved successfully!");
                    loadOrders(model);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to approve order!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an order first!");
            }
        });
        
        rejectBtn.addActionListener(e -> {
            int selectedRow = ordersTable.getSelectedRow();
            if (selectedRow >= 0) {
                int orderId = (int) model.getValueAt(selectedRow, 0);
                String reason = JOptionPane.showInputDialog(this, "Enter rejection reason:");
                if (reason != null && !reason.trim().isEmpty()) {
                    boolean success = adminDAO.updateOrderStatus(orderId, "REJECTED", reason);
                    if (success) {
                        JOptionPane.showMessageDialog(this, "Order rejected!");
                        loadOrders(model);
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to reject order!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an order first!");
            }
        });
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createCustomerManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Customers table
        String[] columns = {"ID", "Name", "Phone", "Email", "Type", "Total Orders", "Total Spent"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable customersTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(customersTable);
        
        // Load customers
        loadCustomers(model);
        
        panel.add(new JLabel("Customer Management", JLabel.CENTER), BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        // Generate report
        double revenue = adminDAO.getTotalRevenue();
        int orders = adminDAO.getTotalOrders();
        List<Customer> customers = adminDAO.getAllCustomers();
        
        StringBuilder report = new StringBuilder();
        report.append("T-LAUNGE RESTAURANT MANAGEMENT SYSTEM REPORT\n");
        report.append("=============================================\n\n");
        report.append(String.format("Total Revenue: $%.2f\n", revenue));
        report.append(String.format("Total Orders: %d\n", orders));
        report.append(String.format("Total Customers: %d\n\n", customers.size()));
        report.append("Recent Orders:\n");
        report.append("--------------\n");
        
        List<Order> recentOrders = adminDAO.getAllOrders();
        int count = Math.min(10, recentOrders.size());
        for (int i = 0; i < count; i++) {
            Order order = recentOrders.get(i);
            report.append(String.format("#%d: %s - $%.2f - %s\n", 
                order.getOrderId(), 
                order.getCustomerName(), 
                order.getTotalAmount(), 
                order.getReceiptStatus()));
        }
        
        reportArea.setText(report.toString());
        
        panel.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private void loadMenuItems(DefaultTableModel model) {
        model.setRowCount(0);
        CategoryDAO categoryDAO = new CategoryDAO();
        
        for (int i = 1; i <= 9; i++) {
            List<MenuItem> items = categoryDAO.getMenuItemsByCategory(i);
            if (items != null) {
                for (MenuItem item : items) {
                    model.addRow(new Object[]{
                        item.getItemId(),
                        item.getItemName(),
                        item.getDescription(),
                        item.getPrice(),
                        getCategoryName(item.getCategoryId()),
                        item.isAvailable() ? "Yes" : "No"
                    });
                }
            }
        }
    }
    
    private void loadOrders(DefaultTableModel model) {
        model.setRowCount(0);
        List<Order> orders = adminDAO.getAllOrders();
        
        if (orders != null) {
            for (Order order : orders) {
                model.addRow(new Object[]{
                    order.getOrderId(),
                    order.getCustomerName(),
                    order.getPhoneNumber(),
                    order.getTotalAmount(),
                    order.getReceiptStatus(),
                    order.getOrderDate()
                });
            }
        }
    }
    
    private void loadCustomers(DefaultTableModel model) {
        model.setRowCount(0);
        List<Customer> customers = adminDAO.getAllCustomers();
        
        if (customers != null) {
            for (Customer customer : customers) {
                model.addRow(new Object[]{
                    customer.getCustomerId(),
                    customer.getFullName(),
                    customer.getPhoneNumber(),
                    customer.getEmail(),
                    customer.getCustomerType(),
                    customer.getTotalOrders(),
                    customer.getTotalSpent()
                });
            }
        }
    }
    
    private String getCategoryName(int categoryId) {
        String[] categories = {"", "Breakfast", "Lunch", "Dinner", "Alcoholic Drinks", 
                              "Mocktails & Soft Drinks", "Fresh Juice", "Hot Drinks", "Sweet Food", "Vegetables"};
        if (categoryId >= 0 && categoryId < categories.length) {
            return categories[categoryId];
        }
        return "Unknown";
    }
    
    private void showAddMenuItemDialog() {
        JDialog dialog = new JDialog(this, "Add Menu Item", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        panel.add(new JLabel("Item Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);
        
        panel.add(new JLabel("Description:"));
        JTextField descField = new JTextField();
        panel.add(descField);
        
        panel.add(new JLabel("Price:"));
        JTextField priceField = new JTextField();
        panel.add(priceField);
        
        panel.add(new JLabel("Category:"));
        JComboBox<String> categoryCombo = new JComboBox<>(new String[]{
            "Breakfast", "Lunch", "Dinner", "Alcoholic Drinks", 
            "Mocktails & Soft Drinks", "Fresh Juice", "Hot Drinks", "Sweet Food", "Vegetables"
        });
        panel.add(categoryCombo);
        
        panel.add(new JLabel("Available:"));
        JCheckBox availableCheck = new JCheckBox("Yes", true);
        panel.add(availableCheck);
        
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        panel.add(saveBtn);
        panel.add(cancelBtn);
        
        saveBtn.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String description = descField.getText();
                double price = Double.parseDouble(priceField.getText());
                String category = (String) categoryCombo.getSelectedItem();
                boolean available = availableCheck.isSelected();
                
                if (name.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Please enter item name!");
                    return;
                }
                
                CategoryDAO categoryDAO = new CategoryDAO();
                int categoryId = categoryDAO.getCategoryIdByName(category);
                
                if (categoryId <= 0) {
                    JOptionPane.showMessageDialog(dialog, "Invalid category selected!");
                    return;
                }
                
                MenuItem newItem = new MenuItem(0, categoryId, name, description, price, available);
                boolean success = adminDAO.addMenuItem(newItem);
                
                if (success) {
                    JOptionPane.showMessageDialog(dialog, "Menu item added successfully!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to add menu item!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter a valid price!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });
        
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void deleteMenuItem(int itemId, DefaultTableModel model) {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this menu item?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = adminDAO.deleteMenuItem(itemId);
            if (success) {
                JOptionPane.showMessageDialog(this, "Menu item deleted successfully!");
                loadMenuItems(model);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete menu item!");
            }
        }
    }
}