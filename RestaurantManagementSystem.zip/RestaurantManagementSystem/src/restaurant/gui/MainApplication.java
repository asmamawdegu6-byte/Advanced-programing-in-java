package restaurant.gui;

import javax.swing.*;
import java.awt.*;

public class MainApplication extends JFrame {
    
    public MainApplication() {
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Restaurant Management System - Main Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Create main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(70, 130, 180);
                Color color2 = new Color(240, 248, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Header
        JLabel headerLabel = new JLabel("T-Launge RESTAURANT MANAGEMENT SYSTEM", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));
        
        // Center panel with options
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Welcome message
        JLabel welcomeLabel = new JLabel("Welcome to Our Restaurant System", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 22));
        welcomeLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        centerPanel.add(welcomeLabel, gbc);
        
        // Option buttons
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        
        JButton userLoginBtn = createOptionButton("User Login", new Color(65, 105, 225));
        gbc.gridx = 0;
        centerPanel.add(userLoginBtn, gbc);
        
        JButton adminLoginBtn = createOptionButton("Admin Login", new Color(70, 130, 180));
        gbc.gridx = 1;
        centerPanel.add(adminLoginBtn, gbc);
        
        gbc.gridy = 2;
        
        JButton guestBtn = createOptionButton("Guest Login", new Color(100, 149, 237));
        gbc.gridx = 0;
        centerPanel.add(guestBtn, gbc);
        
        JButton registerBtn = createOptionButton("Register", new Color(30, 144, 255));
        gbc.gridx = 1;
        centerPanel.add(registerBtn, gbc);
        
        // Footer
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false);
        JLabel footerLabel = new JLabel("© 2024 Group | UOG Tedy Campus | Contact: 0946115656");
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        
        // Button actions
        userLoginBtn.addActionListener(e -> {
            new RestaurantHomePage().setVisible(true);
            dispose();
        });
        
        adminLoginBtn.addActionListener(e -> {
            new AdminLogin().setVisible(true);
        });
        
        guestBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "Please use the main application window for guest login.", 
                "Info", JOptionPane.INFORMATION_MESSAGE);
            new RestaurantHomePage().setVisible(true);
            dispose();
        });
        
        registerBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "Please use the main application window for registration.", 
                "Info", JOptionPane.INFORMATION_MESSAGE);
            new RestaurantHomePage().setVisible(true);
            dispose();
        });
        
        // Add panels to main panel
        mainPanel.add(headerLabel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JButton createOptionButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    public static void main(String[] args) {
        // Set system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Launch the application
        SwingUtilities.invokeLater(() -> {
            MainApplication app = new MainApplication();
            app.setVisible(true);
        });
    }
}