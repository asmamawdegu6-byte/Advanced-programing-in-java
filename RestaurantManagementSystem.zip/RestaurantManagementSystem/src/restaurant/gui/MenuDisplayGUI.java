package restaurant.gui;

import restaurant.dao.MenuDAO;
import restaurant.models.Customer;
import restaurant.models.MenuItem;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class MenuDisplayGUI extends JFrame {
    private JTable menuTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JComboBox<String> categoryFilter;
    private JButton backButton, searchButton;
    private MenuDAO menuDAO;
    private Customer customer;
    
    // Brown color palette
    private final Color BROWN_PRIMARY = new Color(139, 69, 19); // SaddleBrown
    private final Color BROWN_LIGHT = new Color(210, 105, 30); // Chocolate
    private final Color BROWN_DARK = new Color(101, 67, 33); // Dark Brown
    private final Color BROWN_BG = new Color(245, 222, 179); // Wheat
    private final Color BROWN_TABLE_HEADER = new Color(160, 82, 45); // Sienna
    private final Color BROWN_TABLE_ROW = new Color(255, 248, 220); // Cornsilk
    
    public MenuDisplayGUI(Customer customer) {
        this.customer = customer;
        this.menuDAO = new MenuDAO();
        setupGUI();
        loadMenuItems();
        setLocationRelativeTo(null);
    }
    
    private void setupGUI() {
        setTitle("Menu - " + customer.getFullName());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        
        // Set brown theme
        getContentPane().setBackground(BROWN_BG);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(BROWN_BG);
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Header panel with customer info
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Center panel with search and table
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(BROWN_BG);
        
        // Search panel
        JPanel searchPanel = createSearchPanel();
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        
        // Table panel
        JPanel tablePanel = createTablePanel();
        centerPanel.add(tablePanel, BorderLayout.CENTER);
        
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Bottom panel with buttons
        JPanel bottomPanel = createBottomPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Add listeners
        backButton.addActionListener(e -> dispose());
        searchButton.addActionListener(e -> searchItems());
        categoryFilter.addActionListener(e -> filterByCategory());
        
        // Add key listener for real-time search
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchItems();
            }
        });
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BROWN_DARK);
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        // Title
        JLabel titleLabel = new JLabel("ETHIOPIAN RESTAURANT MENU", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new EmptyBorder(5, 0, 5, 0));
        
        // Customer info
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.setBackground(BROWN_DARK);
        infoPanel.setBorder(new EmptyBorder(5, 0, 5, 0));
        
        JLabel customerLabel = new JLabel("Customer: " + customer.getFullName());
        customerLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        customerLabel.setForeground(new Color(255, 215, 0)); // Gold color
        infoPanel.add(customerLabel);
        
        // Date label
        JLabel dateLabel = new JLabel("Date: " + new java.util.Date());
        dateLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        dateLabel.setForeground(Color.LIGHT_GRAY);
        infoPanel.add(Box.createHorizontalStrut(20));
        infoPanel.add(dateLabel);
        
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(infoPanel, BorderLayout.SOUTH);
        
        return headerPanel;
    }
    
    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchPanel.setBackground(new Color(222, 184, 135)); // BurlyWood
        searchPanel.setBorder(new CompoundBorder(
            new LineBorder(BROWN_PRIMARY, 2, true),
            new EmptyBorder(15, 15, 15, 15)
        ));
        
        // Category filter
        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        categoryLabel.setForeground(BROWN_DARK);
        searchPanel.add(categoryLabel);
        
        categoryFilter = new JComboBox<>();
        String[] categories = {
            "All Categories",
            "Traditional Dishes",
            "Meat Dishes",
            "Vegetarian Dishes",
            "Injera & Breads",
            "Breakfast",
            "Side Dishes",
            "Beverages",
            "Desserts"
        };
        for (String category : categories) {
            categoryFilter.addItem(category);
        }
        
        categoryFilter.setBackground(Color.WHITE);
        categoryFilter.setFont(new Font("SansSerif", Font.PLAIN, 13));
        categoryFilter.setPreferredSize(new Dimension(180, 30));
        searchPanel.add(categoryFilter);
        
        // Search field
        searchPanel.add(Box.createHorizontalStrut(20));
        
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        searchLabel.setForeground(BROWN_DARK);
        searchPanel.add(searchLabel);
        
        searchField = new JTextField(25);
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        searchField.setPreferredSize(new Dimension(250, 30));
        searchField.setBorder(new LineBorder(BROWN_LIGHT, 1));
        searchPanel.add(searchField);
        
        // Search button
        searchButton = new JButton("🔍 Search");
        styleButton(searchButton, BROWN_PRIMARY);
        searchButton.setPreferredSize(new Dimension(120, 30));
        searchPanel.add(searchButton);
        
        // Clear button
        JButton clearButton = new JButton("Clear");
        styleButton(clearButton, BROWN_DARK);
        clearButton.setPreferredSize(new Dimension(100, 30));
        clearButton.addActionListener(e -> {
            searchField.setText("");
            categoryFilter.setSelectedIndex(0);
            loadMenuItems();
        });
        searchPanel.add(clearButton);
        
        return searchPanel;
    }
    
    private JPanel createTablePanel() {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(BROWN_BG);
        tablePanel.setBorder(new TitledBorder(
            new LineBorder(BROWN_PRIMARY, 2),
            "Menu Items",
            TitledBorder.CENTER,
            TitledBorder.TOP,
            new Font("Serif", Font.BOLD, 16),
            BROWN_PRIMARY
        ));
        
        // Table columns
        String[] columns = {"ID", "Name", "Price (Birr)", "Category", "Available", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) return Double.class;
                return String.class;
            }
        };
        
        // Create table with custom renderer
        menuTable = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                
                // Alternate row colors
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? BROWN_TABLE_ROW : Color.WHITE);
                }
                
                // Highlight unavailable items
                if (column == 4) {
                    String available = (String) getValueAt(row, column);
                    if ("No".equals(available)) {
                        c.setForeground(Color.RED);
                    } else {
                        c.setForeground(new Color(0, 100, 0)); // Dark Green
                    }
                } else if (column == 2) { // Price column
                    c.setForeground(new Color(0, 0, 139)); // Dark Blue
                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                }
                
                return c;
            }
        };
        
        // Customize table appearance
        menuTable.setRowHeight(30);
        menuTable.setFont(new Font("SansSerif", Font.PLAIN, 13));
        menuTable.setSelectionBackground(BROWN_LIGHT);
        menuTable.setSelectionForeground(Color.WHITE);
        menuTable.setGridColor(BROWN_LIGHT);
        menuTable.setShowGrid(true);
        menuTable.setIntercellSpacing(new Dimension(1, 1));
        
        // Customize table header
        JTableHeader header = menuTable.getTableHeader();
        header.setBackground(BROWN_TABLE_HEADER);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setPreferredSize(new Dimension(header.getWidth(), 35));
        
        // Set column widths
        menuTable.getColumnModel().getColumn(0).setPreferredWidth(50);  // ID
        menuTable.getColumnModel().getColumn(1).setPreferredWidth(200); // Name
        menuTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Price
        menuTable.getColumnModel().getColumn(3).setPreferredWidth(150); // Category
        menuTable.getColumnModel().getColumn(4).setPreferredWidth(80);  // Available
        menuTable.getColumnModel().getColumn(5).setPreferredWidth(300); // Description
        
        // Make price column right-aligned
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        menuTable.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        
        // Center align ID and Available columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        menuTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        menuTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        
        JScrollPane scrollPane = new JScrollPane(menuTable);
        scrollPane.getViewport().setBackground(BROWN_BG);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add status label at bottom of table
        JLabel statusLabel = new JLabel(" Total items: 0");
        statusLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        statusLabel.setForeground(BROWN_DARK);
        statusLabel.setBorder(new EmptyBorder(5, 10, 5, 10));
        tablePanel.add(statusLabel, BorderLayout.SOUTH);
        
        return tablePanel;
    }
    
    private JPanel createBottomPanel() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bottomPanel.setBackground(new Color(210, 180, 140)); // Tan
        
        // Back button
        backButton = new JButton("← Back to Main");
        styleButton(backButton, BROWN_DARK);
        backButton.setPreferredSize(new Dimension(150, 40));
        backButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        bottomPanel.add(backButton);
        
        // Order button
        JButton orderButton = new JButton("📝 Place Order");
        styleButton(orderButton, new Color(0, 100, 0)); // Dark Green
        orderButton.setPreferredSize(new Dimension(150, 40));
        orderButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        orderButton.addActionListener(e -> showOrderDialog());
        bottomPanel.add(orderButton);
        
        // Refresh button
        JButton refreshButton = new JButton("🔄 Refresh Menu");
        styleButton(refreshButton, BROWN_PRIMARY);
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        refreshButton.addActionListener(e -> loadMenuItems());
        bottomPanel.add(refreshButton);
        
        return bottomPanel;
    }
    
    private void styleButton(JButton button, Color bgColor) {
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(
            new LineBorder(bgColor.darker(), 2),
            new EmptyBorder(5, 15, 5, 15)
        ));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }
    
    private void loadMenuItems() {
        // Clear table
        tableModel.setRowCount(0);
        
        try {
            // Get all items from database
            List<MenuItem> items = menuDAO.getAllMenuItems();
            
            if (items != null && !items.isEmpty()) {
                for (MenuItem item : items) {
                    String categoryName = getCategoryName(item.getCategoryId());
                    tableModel.addRow(new Object[]{
                        item.getItemId(),
                        item.getItemName(),
                        item.getPrice(),
                        categoryName,
                        item.isAvailable() ? "Yes" : "No",
                        item.getDescription() != null ? item.getDescription() : ""
                    });
                }
                
                // Update status
                updateStatusLabel(items.size());
                
                // Show success message
                showMessage("Loaded " + items.size() + " menu items", Color.GREEN.darker());
            } else {
                showMessage("No menu items found", Color.ORANGE.darker());
            }
        } catch (Exception e) {
            showMessage("Error loading menu: " + e.getMessage(), Color.RED);
            e.printStackTrace();
        }
    }
    
    private void updateStatusLabel(int count) {
        Component[] comps = ((JPanel)menuTable.getParent().getParent()).getComponents();
        for (Component comp : comps) {
            if (comp instanceof JLabel) {
                ((JLabel)comp).setText(" Total items: " + count + " | Double-click to view details");
                break;
            }
        }
    }
    
    private void showMessage(String message, Color color) {
        JOptionPane.showMessageDialog(this, message, "Menu System", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private String getCategoryName(int categoryId) {
        switch(categoryId) {
            case 1: return "Traditional Dishes";
            case 2: return "Meat Dishes";
            case 3: return "Vegetarian Dishes";
            case 4: return "Injera & Breads";
            case 5: return "Breakfast";
            case 6: return "Side Dishes";
            case 7: return "Beverages";
            case 8: return "Desserts";
            default: return "Unknown";
        }
    }
    
    private void searchItems() {
        String searchText = searchField.getText().trim().toLowerCase();
        String selectedCategory = (String) categoryFilter.getSelectedItem();
        
        // Clear table
        tableModel.setRowCount(0);
        
        try {
            List<MenuItem> items;
            int totalItems = 0;
            
            if (selectedCategory.equals("All Categories")) {
                // Search in all items
                items = menuDAO.getAllMenuItems();
            } else {
                // Get category ID
                int categoryId = getCategoryId(selectedCategory);
                // Get items by category
                items = menuDAO.getMenuItemsByCategory(categoryId);
            }
            
            if (items != null) {
                // Apply search filter
                for (MenuItem item : items) {
                    String categoryName = getCategoryName(item.getCategoryId());
                    
                    // Check if item matches search text
                    boolean matchesSearch = searchText.isEmpty() ||
                        item.getItemName().toLowerCase().contains(searchText) ||
                        (item.getDescription() != null && 
                         item.getDescription().toLowerCase().contains(searchText));
                    
                    if (matchesSearch) {
                        tableModel.addRow(new Object[]{
                            item.getItemId(),
                            item.getItemName(),
                            item.getPrice(),
                            categoryName,
                            item.isAvailable() ? "Yes" : "No",
                            item.getDescription() != null ? item.getDescription() : ""
                        });
                        totalItems++;
                    }
                }
                
                updateStatusLabel(totalItems);
                
                if (totalItems == 0) {
                    showMessage("No items found matching your criteria", Color.ORANGE.darker());
                }
            }
        } catch (Exception e) {
            showMessage("Error searching: " + e.getMessage(), Color.RED);
            e.printStackTrace();
        }
    }
    
    private void filterByCategory() {
        searchItems(); // Reuse search functionality
    }
    
    private int getCategoryId(String categoryName) {
        switch(categoryName) {
            case "Traditional Dishes": return 1;
            case "Meat Dishes": return 2;
            case "Vegetarian Dishes": return 3;
            case "Injera & Breads": return 4;
            case "Breakfast": return 5;
            case "Side Dishes": return 6;
            case "Beverages": return 7;
            case "Desserts": return 8;
            default: return 0;
        }
    }
    
    private void showOrderDialog() {
        int selectedRow = menuTable.getSelectedRow();
        if (selectedRow == -1) {
            showMessage("Please select an item to order", Color.ORANGE.darker());
            return;
        }
        
        String itemName = (String) tableModel.getValueAt(selectedRow, 1);
        double price = (Double) tableModel.getValueAt(selectedRow, 2);
        String available = (String) tableModel.getValueAt(selectedRow, 4);
        
        if ("No".equals(available)) {
            showMessage("Sorry, " + itemName + " is not available", Color.RED);
            return;
        }
        
        // Create order dialog
        JDialog orderDialog = new JDialog(this, "Place Order", true);
        orderDialog.setSize(400, 300);
        orderDialog.setLocationRelativeTo(this);
        orderDialog.getContentPane().setBackground(BROWN_BG);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BROWN_BG);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Item info
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Item:"), gbc);
        gbc.gridx = 1;
        JLabel itemLabel = new JLabel(itemName);
        itemLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        itemLabel.setForeground(BROWN_PRIMARY);
        panel.add(itemLabel, gbc);
        
        // Price
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Price:"), gbc);
        gbc.gridx = 1;
        JLabel priceLabel = new JLabel(String.format("Birr %.2f", price));
        priceLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        priceLabel.setForeground(new Color(0, 0, 139));
        panel.add(priceLabel, gbc);
        
        // Quantity
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Quantity:"), gbc);
        gbc.gridx = 1;
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(1, 1, 20, 1);
        JSpinner quantitySpinner = new JSpinner(spinnerModel);
        quantitySpinner.setFont(new Font("SansSerif", Font.PLAIN, 14));
        panel.add(quantitySpinner, gbc);
        
        // Total
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Total:"), gbc);
        gbc.gridx = 1;
        JLabel totalLabel = new JLabel(String.format("Birr %.2f", price));
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        totalLabel.setForeground(new Color(0, 100, 0));
        panel.add(totalLabel, gbc);
        
        // Update total when quantity changes
        quantitySpinner.addChangeListener(e -> {
            int quantity = (Integer) quantitySpinner.getValue();
            double total = price * quantity;
            totalLabel.setText(String.format("Birr %.2f", total));
        });
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(BROWN_BG);
        
        JButton confirmButton = new JButton("Confirm Order");
        styleButton(confirmButton, new Color(0, 100, 0));
        confirmButton.addActionListener(e -> {
            int quantity = (Integer) quantitySpinner.getValue();
            showMessage("Order placed: " + quantity + " x " + itemName, Color.GREEN.darker());
            orderDialog.dispose();
        });
        
        JButton cancelButton = new JButton("Cancel");
        styleButton(cancelButton, BROWN_DARK);
        cancelButton.addActionListener(e -> orderDialog.dispose());
        
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(buttonPanel, gbc);
        
        orderDialog.add(panel);
        orderDialog.setVisible(true);
    }
    
    public static void main(String[] args) {
        try {
            // Set brownish look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            // Customize some UI colors
            UIManager.put("Panel.background", new Color(245, 222, 179));
            UIManager.put("Button.background", new Color(139, 69, 19));
            UIManager.put("Button.foreground", Color.WHITE);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            Customer testCustomer = new Customer();
            testCustomer.setFullName("Test Customer");
            
            MenuDisplayGUI gui = new MenuDisplayGUI(testCustomer);
            gui.setVisible(true);
        });
    }
}