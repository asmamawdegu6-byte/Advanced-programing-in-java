package restaurant.db;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordHasher {
    
    // Simple SHA-256 with salt implementation
    // For production, consider using BCrypt or Argon2
    public static String hashPassword(String password) {
        try {
            if (password == null || password.isEmpty()) {
                return "";
            }
            
            // Create a salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);
            
            // Combine password and salt
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(password.getBytes());
            
            // Combine salt and hash for storage
            byte[] combined = new byte[salt.length + hashedPassword.length];
            System.arraycopy(salt, 0, combined, 0, salt.length);
            System.arraycopy(hashedPassword, 0, combined, salt.length, hashedPassword.length);
            
            return Base64.getEncoder().encodeToString(combined);
            
        } catch (NoSuchAlgorithmException e) {
            // Fallback to simple hash if SHA-256 not available
            return Integer.toHexString(password.hashCode());
        }
    }
    
    public static boolean verifyPassword(String password, String storedHash) {
        try {
            if (password == null || storedHash == null || storedHash.isEmpty()) {
                return false;
            }
            
            // Try to decode as Base64 (for SHA-256 with salt)
            try {
                byte[] combined = Base64.getDecoder().decode(storedHash);
                
                // If decoding works, it's our SHA-256 hash
                if (combined.length > 16) {
                    // Extract salt (first 16 bytes)
                    byte[] salt = new byte[16];
                    System.arraycopy(combined, 0, salt, 0, salt.length);
                    
                    // Extract stored hash (remaining bytes)
                    byte[] storedPasswordHash = new byte[combined.length - 16];
                    System.arraycopy(combined, 16, storedPasswordHash, 0, storedPasswordHash.length);
                    
                    // Hash the provided password with the same salt
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    md.update(salt);
                    byte[] hashedPassword = md.digest(password.getBytes());
                    
                    // Compare hashes
                    return MessageDigest.isEqual(storedPasswordHash, hashedPassword);
                }
            } catch (IllegalArgumentException e) {
                // Not Base64 encoded, try simple hash comparison
                return storedHash.equals(Integer.toHexString(password.hashCode()));
            }
            
        } catch (NoSuchAlgorithmException e) {
            // Fallback to simple comparison
            return storedHash.equals(Integer.toHexString(password.hashCode()));
        }
        return false;
    }
}