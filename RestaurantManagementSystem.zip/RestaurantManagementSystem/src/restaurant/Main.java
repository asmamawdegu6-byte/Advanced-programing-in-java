package restaurant;

import restaurant.gui.RestaurantHomePage;

public class Main {
    public static void main(String[] args) {
        System.out.println("Restaurant Management System Starting...");
        RestaurantHomePage.main(args);
    }
}